# MV.tech Brand Kit — essentials

Everything you need to represent MV.tech correctly: logos, colours, type, icons and the guidelines.

## Five rules
1. **Use the vector masters.** `02_Logos/00_Master_Vector` holds the originals. Send those to printers and designers; the PNGs are for everyday work.
2. **Match the logo to the background.** Dark surfaces take the silver *dark* logo, white and pale surfaces the navy *light* logo.
3. **When unsure, use a safe file.** Anything ending `-on-ink` or `-on-white` carries its own background and clear space.
4. **Keep one dot of clear space.** Nothing may enter the area around the logo equal to the teal dot's diameter.
5. **MV never appears twice.** The monogram *is* the letters M and V, and its dot is the full stop, so a lockup pairs the mark with `tech` only — never with the full `MV.tech` wordmark. Never retype the wordmark in a font.

## What is here
| Folder | Contents |
|---|---|
| `02_Logos/00_Master_Vector` | True-vector masters, SVG and PDF — the source of truth |
| `02_Logos/01…06` | PNG exports at 512 and 1024 px in every variant |
| `02_Logos/07_Favicons_and_App_Icons` | favicon.ico, favicon.svg, app and maskable icons, head snippet |
| `02_Logos/08_Social_Profile_Avatars` | Circle-safe avatars for every platform |
| `03_Guidelines` | Full brand guidelines and a one-page quick reference |
| `04_Fonts` | Inter for desktop and web, with the open font licence |
| `05_Colour_and_Tokens` | Palette as JSON, CSS, SCSS, Tailwind, W3C tokens, Adobe and GIMP swatches |
| `06_Icons` | Brand icon set in three colourways |

## Colour
Ink `#05060B` · Navy `#071118` · Signal Teal `#10F5D0` · System Cyan `#00BFCB` · Teal Ink `#007E7B` · Silver `#F4F6F8` · Graphite `#405466`

On white, body text is Navy or Graphite and links are Teal Ink. Signal Teal and System Cyan fail contrast on white and are decorative there only.

## Need more?
Print-ready business cards, letterhead, Word and PowerPoint templates, email signatures and the full social set are in the complete kit. Ask at contact@mvtech.solutions.

MV.tech · contact@mvtech.solutions · mvtech.solutions · Ahmedabad, Gujarat, India
