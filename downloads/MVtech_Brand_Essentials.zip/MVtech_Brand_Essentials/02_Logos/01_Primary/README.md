# 01_Primary — primary lockup (monogram + wordmark + descriptor + slogan) — PNG / WebP / JPG exports

The hero logo: monogram left, `MV.tech` wordmark right, `DATA | AI | DIGITAL SOLUTIONS` and `SOLUTIONS THAT SCALE` under the wordmark. Use it on title pages, brochures, banners, hero sections — anywhere the logo is the main element and has room.

**Minimum size: 320 px wide on screen / 55 mm wide in print.** Below that the descriptor and slogan become unreadable — switch to `02_Horizontal` (min 160 px) and then to `04_Monogram` (min 24 px). The 128 px and 256 px files are here for thumbnails and previews only; do not use them as the visible logo.

**Naming:** `mvtech-primary-<variant>-<width>.png`. The number is the exact **pixel width**; height follows the master's aspect ratio (transparent files 4443.54 : 1112.37 ≈ 4.0 : 1, safe versions 4848.71 : 1517.55 ≈ 3.2 : 1 because they include the clear space). The 8000 px safe versions are for print and large-format use (8000 px ≈ 68 cm at 300 dpi).

## Which file do I use?

| Surface you are placing the logo on | Use | Notes |
|---|---|---|
| Ink (#05060B), navy, photos, any **dark** surface | `…-dark-<size>.png` / `.webp` | Silver artwork + teal V arm, **transparent** background |
| White, Silver (#F4F6F8), any **white or pale** surface | `…-light-<size>.png` / `.webp` | Navy (#071118) artwork + teal V arm, **transparent** background |
| You cannot control the background (slides, docs, partner sites, marketplaces) | `…-dark-on-ink-<size>.png` or `…-light-on-white-<size>.png` | **Safe versions**: background and clear space are baked in. When unsure, use these. |
| One-colour production (engraving, embossing, fax, watermark) | `06_Monochrome/…-mono-black` or `…-mono-white` | Every region incl. the dot in one colour |

> **The transparent `-dark-…` files look empty in a white file browser / Finder / Explorer preview.** Nothing is missing — the artwork is silver and white on a transparent background. Drop the file onto a dark surface (or open the matching `-dark-on-ink-` file) to see it.

## Formats
- **PNG** — every size; RGBA (transparent) for `dark`/`light`, RGB (opaque) for the `-on-ink`/`-on-white` safe versions.
- **WebP (lossless)** — `dark`/`light` at 512, 1024 and 2048, pixel-identical to the PNGs, ~2–3× smaller. Use on the web.
- **JPG (quality 92)** — `-on-ink`/`-on-white` at 2048 only, for tools that refuse PNG (some CRMs, ad platforms, directory listings). JPG cannot be transparent, which is why only the safe versions exist as JPG.

## Rules (from the brand guidelines)
- Clear space: keep one **dot diameter** free on every side of the transparent files. The `-on-ink`/`-on-white` files already include it — do not add more padding around them, and do not crop it away.
- Never stretch, rotate, recolour, outline, add shadows/glows, change the gradient, or separate the dot from the mark. Never retype "MV.tech" in a font.
- Need a size that is not here, a print file, or EPS/AI? Use the true-vector masters in `../00_Master_Vector/` — every file in this folder is exported from them.

## Inventory (34 files)
| File | Pixels (W×H) | Mode | Size |
|---|---|---|---|
| `mvtech-primary-dark-1024.png` | 1024×256 | transparent | 38 KB |
| `mvtech-primary-dark-1024.webp` | 1024×256 | transparent | 19 KB |
| `mvtech-primary-dark-128.png` | 128×32 | transparent | 3 KB |
| `mvtech-primary-dark-2048.png` | 2048×513 | transparent | 113 KB |
| `mvtech-primary-dark-2048.webp` | 2048×513 | transparent | 39 KB |
| `mvtech-primary-dark-256.png` | 256×64 | transparent | 6 KB |
| `mvtech-primary-dark-4096.png` | 4096×1025 | transparent | 345 KB |
| `mvtech-primary-dark-512.png` | 512×128 | transparent | 15 KB |
| `mvtech-primary-dark-512.webp` | 512×128 | transparent | 9 KB |
| `mvtech-primary-dark-on-ink-1024.png` | 1024×320 | opaque | 32 KB |
| `mvtech-primary-dark-on-ink-128.png` | 128×40 | opaque | 3 KB |
| `mvtech-primary-dark-on-ink-2048.jpg` | 2048×641 | opaque | 101 KB |
| `mvtech-primary-dark-on-ink-2048.png` | 2048×641 | opaque | 93 KB |
| `mvtech-primary-dark-on-ink-256.png` | 256×80 | opaque | 6 KB |
| `mvtech-primary-dark-on-ink-4096.png` | 4096×1282 | opaque | 277 KB |
| `mvtech-primary-dark-on-ink-512.png` | 512×160 | opaque | 13 KB |
| `mvtech-primary-dark-on-ink-8000.png` | 8000×2504 | opaque | 749 KB |
| `mvtech-primary-light-1024.png` | 1024×256 | transparent | 24 KB |
| `mvtech-primary-light-1024.webp` | 1024×256 | transparent | 13 KB |
| `mvtech-primary-light-128.png` | 128×32 | transparent | 2 KB |
| `mvtech-primary-light-2048.png` | 2048×513 | transparent | 70 KB |
| `mvtech-primary-light-2048.webp` | 2048×513 | transparent | 26 KB |
| `mvtech-primary-light-256.png` | 256×64 | transparent | 5 KB |
| `mvtech-primary-light-4096.png` | 4096×1025 | transparent | 207 KB |
| `mvtech-primary-light-512.png` | 512×128 | transparent | 10 KB |
| `mvtech-primary-light-512.webp` | 512×128 | transparent | 6 KB |
| `mvtech-primary-light-on-white-1024.png` | 1024×320 | opaque | 21 KB |
| `mvtech-primary-light-on-white-128.png` | 128×40 | opaque | 2 KB |
| `mvtech-primary-light-on-white-2048.jpg` | 2048×641 | opaque | 104 KB |
| `mvtech-primary-light-on-white-2048.png` | 2048×641 | opaque | 57 KB |
| `mvtech-primary-light-on-white-256.png` | 256×80 | opaque | 4 KB |
| `mvtech-primary-light-on-white-4096.png` | 4096×1282 | opaque | 169 KB |
| `mvtech-primary-light-on-white-512.png` | 512×160 | opaque | 9 KB |
| `mvtech-primary-light-on-white-8000.png` | 8000×2504 | opaque | 476 KB |
