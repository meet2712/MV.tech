# 06_Monochrome — one-colour versions (black and white) — PNG exports

Every region of the mark — N, V arms, facet **and the dot** — in a single flat colour. Use these **only** when production forbids colour or gradients: laser engraving, embossing/debossing, foil, screen printing in one ink, fax, rubber stamps, watermarks, document headers printed in black only. Whenever colour is available, use the colour files in `01_Primary` … `05_Wordmark` instead.

| Surface | Use |
|---|---|
| White, pale or light surfaces; black-only print | `mvtech-<family>-mono-black-<size>.png` (pure #000000, transparent) |
| Ink, navy, dark surfaces; white foil / knock-out | `mvtech-<family>-mono-white-<size>.png` (pure #FFFFFF, transparent) |

> **The `-mono-white-` files look empty in a white file browser / Finder / Explorer preview.** They are white artwork on a transparent background — place them on a dark surface to see them.

Families and sizes: `primary`, `horizontal`, `wordmark` (number = **width**), `vertical`, `monogram` (number = **height**), each at 512, 1024, 2048 and 4096 px, transparent PNG only. Minimum sizes are the same as the colour versions: primary 320 px / 55 mm, horizontal 160 px / 35 mm, monogram 24 px / 8 mm. For other sizes or true vector, use `../00_Master_Vector/mvtech-*-mono-black.svg` / `-mono-white.svg` (+ `.pdf`).

Rules: never add a colour, gradient, outline or shadow to a monochrome file; never recolour it to grey — if you need a tint, apply it to the whole mark uniformly in the production tool and keep the dot attached.

## Inventory (40 files)
| File | Pixels (W×H) | Mode | Size |
|---|---|---|---|
| `mvtech-horizontal-mono-black-1024.png` | 1024×230 | transparent | 7 KB |
| `mvtech-horizontal-mono-black-2048.png` | 2048×461 | transparent | 17 KB |
| `mvtech-horizontal-mono-black-4096.png` | 4096×922 | transparent | 45 KB |
| `mvtech-horizontal-mono-black-512.png` | 512×115 | transparent | 3 KB |
| `mvtech-horizontal-mono-white-1024.png` | 1024×230 | transparent | 8 KB |
| `mvtech-horizontal-mono-white-2048.png` | 2048×461 | transparent | 18 KB |
| `mvtech-horizontal-mono-white-4096.png` | 4096×922 | transparent | 47 KB |
| `mvtech-horizontal-mono-white-512.png` | 512×115 | transparent | 4 KB |
| `mvtech-monogram-mono-black-1024.png` | 1810×1024 | transparent | 24 KB |
| `mvtech-monogram-mono-black-2048.png` | 3621×2048 | transparent | 67 KB |
| `mvtech-monogram-mono-black-4096.png` | 7242×4096 | transparent | 195 KB |
| `mvtech-monogram-mono-black-512.png` | 905×512 | transparent | 9 KB |
| `mvtech-monogram-mono-white-1024.png` | 1810×1024 | transparent | 25 KB |
| `mvtech-monogram-mono-white-2048.png` | 3621×2048 | transparent | 71 KB |
| `mvtech-monogram-mono-white-4096.png` | 7242×4096 | transparent | 205 KB |
| `mvtech-monogram-mono-white-512.png` | 905×512 | transparent | 9 KB |
| `mvtech-primary-mono-black-1024.png` | 1024×256 | transparent | 11 KB |
| `mvtech-primary-mono-black-2048.png` | 2048×513 | transparent | 24 KB |
| `mvtech-primary-mono-black-4096.png` | 4096×1025 | transparent | 57 KB |
| `mvtech-primary-mono-black-512.png` | 512×128 | transparent | 5 KB |
| `mvtech-primary-mono-white-1024.png` | 1024×256 | transparent | 12 KB |
| `mvtech-primary-mono-white-2048.png` | 2048×513 | transparent | 26 KB |
| `mvtech-primary-mono-white-4096.png` | 4096×1025 | transparent | 61 KB |
| `mvtech-primary-mono-white-512.png` | 512×128 | transparent | 5 KB |
| `mvtech-vertical-mono-black-1024.png` | 1152×1024 | transparent | 25 KB |
| `mvtech-vertical-mono-black-2048.png` | 2305×2048 | transparent | 60 KB |
| `mvtech-vertical-mono-black-4096.png` | 4609×4096 | transparent | 166 KB |
| `mvtech-vertical-mono-black-512.png` | 576×512 | transparent | 11 KB |
| `mvtech-vertical-mono-white-1024.png` | 1152×1024 | transparent | 26 KB |
| `mvtech-vertical-mono-white-2048.png` | 2305×2048 | transparent | 61 KB |
| `mvtech-vertical-mono-white-4096.png` | 4609×4096 | transparent | 172 KB |
| `mvtech-vertical-mono-white-512.png` | 576×512 | transparent | 12 KB |
| `mvtech-wordmark-mono-black-1024.png` | 1024×167 | transparent | 6 KB |
| `mvtech-wordmark-mono-black-2048.png` | 2048×334 | transparent | 14 KB |
| `mvtech-wordmark-mono-black-4096.png` | 4096×669 | transparent | 35 KB |
| `mvtech-wordmark-mono-black-512.png` | 512×84 | transparent | 3 KB |
| `mvtech-wordmark-mono-white-1024.png` | 1024×167 | transparent | 6 KB |
| `mvtech-wordmark-mono-white-2048.png` | 2048×334 | transparent | 14 KB |
| `mvtech-wordmark-mono-white-4096.png` | 4096×669 | transparent | 37 KB |
| `mvtech-wordmark-mono-white-512.png` | 512×84 | transparent | 3 KB |
