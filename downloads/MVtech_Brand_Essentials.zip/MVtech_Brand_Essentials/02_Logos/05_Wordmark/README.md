# 05_Wordmark — `MV.tech` letterforms alone — PNG / WebP / JPG exports

The wordmark without the monogram: bold `MV`, small Signal Teal dot on the baseline, regular `tech`. Use it in headers and footers, running heads, and places where the monogram is already present nearby. The letterforms are artwork traced from the approved logo — never retype `MV.tech` in a font.

**Minimum size.** The brand rules set no separate minimum for the wordmark alone. Derived from the horizontal-lockup minimum (160 px), in which the wordmark is ~93 px wide: keep the wordmark **at least ~95 px wide (~20 mm in print)**; the 128 px export is the smallest one you should place. Below that, use the monogram.

**Naming:** `mvtech-wordmark-<variant>-<width>.png`. The number is the exact **pixel width**; height follows the master's aspect ratio (transparent files 3153.03 : 514.78 ≈ 6.1 : 1, safe versions 3358.94 : 720.69 ≈ 4.7 : 1). The safe versions were composed from the wordmark master with a background and a clear-space margin of 0.2 × the wordmark height on all sides.

## Which file do I use?

| Surface you are placing the logo on | Use | Notes |
|---|---|---|
| Ink (#05060B), navy, photos, any **dark** surface | `…-dark-<size>.png` / `.webp` | Silver artwork + teal V arm, **transparent** background |
| White, Silver (#F4F6F8), any **white or pale** surface | `…-light-<size>.png` / `.webp` | Navy (#071118) artwork + teal V arm, **transparent** background |
| You cannot control the background (slides, docs, partner sites, marketplaces) | `…-dark-on-ink-<size>.png` or `…-light-on-white-<size>.png` | **Safe versions**: background and clear space are baked in. When unsure, use these. |
| One-colour production (engraving, embossing, fax, watermark) | `06_Monochrome/…-mono-black` or `…-mono-white` | Every region incl. the dot in one colour |

> **The transparent `-dark-…` files look empty in a white file browser / Finder / Explorer preview.** Nothing is missing — the artwork is silver and white on a transparent background. Drop the file onto a dark surface (or open the matching `-dark-on-ink-` file) to see it.

## Formats
- **PNG** — every size; RGBA (transparent) for `dark`/`light`, RGB (opaque) for the `-on-ink`/`-on-white` safe versions.
- **WebP (lossless)** — `dark`/`light` at 512, 1024 and 2048, pixel-identical to the PNGs, ~2–3× smaller. Use on the web.
- **JPG (quality 92)** — `-on-ink`/`-on-white` at 2048 only, for tools that refuse PNG (some CRMs, ad platforms, directory listings). JPG cannot be transparent, which is why only the safe versions exist as JPG.

## Rules (from the brand guidelines)
- Clear space: for the wordmark alone keep at least **0.2 × the wordmark height** free on every side of the transparent files (in the lockups the rule is one monogram-dot diameter). The `-on-ink`/`-on-white` files already include it — do not add more padding around them, and do not crop it away.
- Never stretch, rotate, recolour, outline, add shadows/glows, change the gradient, or separate the dot from the mark. Never retype "MV.tech" in a font.
- Need a size that is not here, a print file, or EPS/AI? Use the true-vector masters in `../00_Master_Vector/` — every file in this folder is exported from them.

## Inventory (32 files)
| File | Pixels (W×H) | Mode | Size |
|---|---|---|---|
| `mvtech-wordmark-dark-1024.png` | 1024×167 | transparent | 6 KB |
| `mvtech-wordmark-dark-1024.webp` | 1024×167 | transparent | 3 KB |
| `mvtech-wordmark-dark-128.png` | 128×21 | transparent | 1 KB |
| `mvtech-wordmark-dark-2048.png` | 2048×334 | transparent | 15 KB |
| `mvtech-wordmark-dark-2048.webp` | 2048×334 | transparent | 7 KB |
| `mvtech-wordmark-dark-256.png` | 256×42 | transparent | 2 KB |
| `mvtech-wordmark-dark-4096.png` | 4096×669 | transparent | 38 KB |
| `mvtech-wordmark-dark-512.png` | 512×84 | transparent | 3 KB |
| `mvtech-wordmark-dark-512.webp` | 512×84 | transparent | 2 KB |
| `mvtech-wordmark-dark-on-ink-1024.png` | 1024×220 | opaque | 7 KB |
| `mvtech-wordmark-dark-on-ink-128.png` | 128×27 | opaque | 1 KB |
| `mvtech-wordmark-dark-on-ink-2048.jpg` | 2048×439 | opaque | 59 KB |
| `mvtech-wordmark-dark-on-ink-2048.png` | 2048×439 | opaque | 14 KB |
| `mvtech-wordmark-dark-on-ink-256.png` | 256×55 | opaque | 2 KB |
| `mvtech-wordmark-dark-on-ink-4096.png` | 4096×879 | opaque | 35 KB |
| `mvtech-wordmark-dark-on-ink-512.png` | 512×110 | opaque | 3 KB |
| `mvtech-wordmark-light-1024.png` | 1024×167 | transparent | 7 KB |
| `mvtech-wordmark-light-1024.webp` | 1024×167 | transparent | 3 KB |
| `mvtech-wordmark-light-128.png` | 128×21 | transparent | 1 KB |
| `mvtech-wordmark-light-2048.png` | 2048×334 | transparent | 16 KB |
| `mvtech-wordmark-light-2048.webp` | 2048×334 | transparent | 7 KB |
| `mvtech-wordmark-light-256.png` | 256×42 | transparent | 2 KB |
| `mvtech-wordmark-light-4096.png` | 4096×669 | transparent | 42 KB |
| `mvtech-wordmark-light-512.png` | 512×84 | transparent | 4 KB |
| `mvtech-wordmark-light-512.webp` | 512×84 | transparent | 2 KB |
| `mvtech-wordmark-light-on-white-1024.png` | 1024×220 | opaque | 7 KB |
| `mvtech-wordmark-light-on-white-128.png` | 128×27 | opaque | 1 KB |
| `mvtech-wordmark-light-on-white-2048.jpg` | 2048×439 | opaque | 63 KB |
| `mvtech-wordmark-light-on-white-2048.png` | 2048×439 | opaque | 14 KB |
| `mvtech-wordmark-light-on-white-256.png` | 256×55 | opaque | 2 KB |
| `mvtech-wordmark-light-on-white-4096.png` | 4096×879 | opaque | 36 KB |
| `mvtech-wordmark-light-on-white-512.png` | 512×110 | opaque | 3 KB |
