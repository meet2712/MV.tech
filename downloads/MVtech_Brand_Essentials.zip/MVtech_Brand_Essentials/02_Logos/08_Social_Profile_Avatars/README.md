# 08_Social_Profile_Avatars — MV.tech v2

Square, circle-safe profile pictures built from the true-vector monogram in `../00_Master_Vector/`
(`mvtech-monogram-dark.svg` on Ink, `mvtech-monogram-light.svg` on white). All files are opaque RGB PNGs
(no transparency, so no platform can flatten them onto an unexpected colour) and every pixel size in a
file name is exact.

## Which file for which platform

| Platform / use | File | Size |
|---|---|---|
| LinkedIn company page logo | `mvtech-linkedin-company-logo-400.png` (fallback `mvtech-linkedin-company-logo-300.png`) | 400 / 300 px |
| X (Twitter) profile picture | `mvtech-x-twitter-profile-400.png` | 400 px |
| Instagram profile picture | `mvtech-instagram-profile-320.png` | 320 px |
| YouTube channel picture | `mvtech-youtube-profile-800.png` | 800 px |
| WhatsApp Business profile photo | `mvtech-whatsapp-profile-640.png` | 640 px |
| Google Business Profile logo | `mvtech-google-business-profile-720.png` | 720 px |
| Anything else that wants a dark avatar (GitHub org, Slack/Teams workspace, Calendly, Gravatar, Discord, app stores, CRM) | `mvtech-avatar-dark-1024.png` — or the 400 / 800 / 1080 px version closest to the platform's stated size | 400 / 800 / 1024 / 1080 px |
| Light-interface contexts where a white tile is required (e.g. a partner directory, marketplace listing, print-style directory) | `mvtech-avatar-light-<size>.png` | 400 / 800 / 1024 / 1080 px |
| Campaign / "live" / featured variants where a highlight ring is wanted | `mvtech-avatar-dark-ring-<size>.png` | 400 / 800 / 1024 / 1080 px |

Platform sizes are the platforms' commonly published recommendations at the time of writing; check the
platform's current help page before uploading and pick the nearest file (never upscale — use a larger
file and let the platform downsample).

Default choice: **dark**. The Ink background is the brand's primary surface and it keeps the silver mark and
Signal Teal arm at full contrast on both light and dark app themes. Use **light** only where a white tile is
required. All platform-specific files are the dark composition.

## How the files are composed (circle-safe rule)

Most platforms crop profile pictures to a circle. Every file here is built so the monogram's full bounding
box sits inside the inscribed circle with a safety margin:

- Bounding-box corners of the mark lie at 0.4175 × side from the centre, i.e. the mark keeps **≥ 8 % of the
  avatar width** (≥ 16 % of the circle radius) clear of the circle edge. Pixel-measured margin on every
  file: 8.24 – 8.36 % of the width.
- Resulting mark size: 72.5 % of the side wide, 42 % of the side tall, geometrically centred.
- The mark is the complete monogram artwork (N + silver V arm, dark facet, teal V arm, Signal Teal dot),
  including the V's rounded bottom — nothing is trimmed.
- **Ring variant**: a solid Signal Teal (#10F5D0) ring, stroke = 2 % of the width, outer edge inset 2 % of
  the width from the square edge (ring spans radius 0.46 – 0.48 × side), so it survives the platform's circle
  crop with a thin Ink margin outside it.
- Backgrounds: dark files = Ink #05060B; light files = White #FFFFFF with the Navy #071118 monogram.

`mvtech-avatar-circle-preview.png` shows every file masked to its circle on a light and on a dark interface,
with a hairline at the crop boundary — use it to sanity-check before uploading.

## Rules
- Do not crop tighter, re-centre, add text or a wordmark, or change the background colour — the safe margin
  is what keeps the mark intact after the platform's circular crop.
- Do not upload the transparent monogram PNGs from `04_Monogram/` as a profile picture; platforms flatten
  transparency unpredictably. Use these files.
- Do not use the light avatar and the dark avatar side by side on the same platform; pick one per account.
- Need another size? Re-export from the master SVG using the composition rule above (mark bbox corners at
  0.4175 × side); do not resample these PNGs upwards.
