# 00_Master_Vector — the source of truth for every MV.tech logo

Everything in this folder is **true vector**: lines, arcs and Bézier paths only. No embedded bitmaps, no live text, no font dependencies. Every PNG, WebP, ICO and PDF elsewhere in this kit is exported from these files. Send these to printers, sign makers, developers and designers.

| File | What it is | Use it for |
|---|---|---|
| `mvtech-monogram-{dark,light,mono-black,mono-white}.svg/.pdf` | The angular MV mark alone | favicons, avatars, app icons, watermarks, small spaces |
| `mvtech-wordmark-{…}.svg/.pdf` | "MV.tech" letterforms (artwork traced from the approved logo; never retype it) | anywhere the name must be spelled out and the mark is not present |
| `mvtech-lockup-horizontal-{…}.svg/.pdf` | Monogram + "tech" — the mark supplies the "MV." | website header, email signature, slide footers, co-branding |
| `mvtech-lockup-primary-{…}.svg/.pdf` | Monogram + "tech", then descriptor and slogan | title pages, brochures, banners, anywhere the logo is the hero |
| `mvtech-lockup-vertical-{…}.svg/.pdf` | Stacked lockup with descriptor + slogan | square/portrait spaces, social posts, print covers |
| `…-dark-on-ink.svg/.pdf` and `…-light-on-white.svg/.pdf` | "Safe" versions **with** a background and built-in clear space (available for all three lockups and for the monogram and wordmark) | pasting into slides, documents or third-party sites when you cannot control the background |


## The one rule people get wrong

**"MV" must never appear twice.** The monogram *is* the letters M and V, and its teal dot is the
full stop. So a lockup pairs the mark with `tech` only — never with the full `MV.tech` wordmark.
Use the standalone wordmark when the name has to be spelled out on its own; use the monogram alone
as a small symbol (favicon, app icon, avatar); use a lockup when you want both together.

## Which colour variant
- **dark** — silver/white artwork with the teal V arm. For Ink (#05060B) or any dark surface. The transparent file is invisible on white — use `-dark-on-ink` to preview it.
- **light** — Navy (#071118) artwork with the teal V arm. For white or pale surfaces.
- **mono-black / mono-white** — single colour including the dot. Only when production forbids colour (engraving, embossing, fax, one-colour print, watermarks).

## Rules
- Clear space: keep at least one **dot diameter** free on every side (the `-on-ink` / `-on-white` files already include it).
- Minimum size: monogram 24 px / 8 mm; horizontal lockup 160 px / 35 mm; primary lockup 320 px / 55 mm (below that, drop to the horizontal lockup, then the monogram). These are measured across the whole lockup. Because the lockup is now narrower than the old monogram-plus-wordmark version, holding the same width makes the mark itself print larger than before — if you need mark-size parity with the previous edition instead, use 33 mm for the primary and 42 mm for the horizontal and say so in the job spec.
- Never stretch, rotate, outline, add shadows, change the gradient, recolour the dot or separate it from the mark. Never retype "MV.tech" in a font.
- Descriptor `DATA | AI | DIGITAL SOLUTIONS` and slogan `SOLUTIONS THAT SCALE` inside the lockups are Inter glyph outlines; they are part of the artwork and must not be edited separately.

## Technical notes
- SVGs: viewBox origin 0 0, tight to the artwork (the `-on-*` files add the clear space), `width`/`height` equal to the viewBox, ids prefixed per file so several logos can be inlined into one HTML page or SVG sprite without id clashes.
- Gradients are `userSpaceOnUse` so they follow the whole mark. Hex values are from `10_Color_and_Design_Tokens/mvtech-palette.json`.
- PDFs are single-page vector files (no fonts, no images) sized 120 mm wide (components) or 200 mm wide (lockups); scale freely.
- 30 SVG masters, each with a matching vector PDF.
- Monogram geometry: fitted to the approved artwork with 27 nodes (straight edges are exactly straight, the V bottom is a true arc). Wordmark: potrace of the approved reference at 4× (IoU 0.996), 6 glyph paths + dot.
- Need EPS or AI? Open the PDF in Illustrator/Affinity/Inkscape and "Save as" — the geometry is already vector.
