# 07_Favicons_and_App_Icons

Browser-tab, home-screen, PWA and Windows-tile icons for mvtech.solutions. Every file here is exported from the true-vector master `../00_Master_Vector/mvtech-monogram-dark.svg` (the pinned-tab mask from `mvtech-monogram-mono-black.svg`). Nothing is traced from or upscaled out of a bitmap. Do not edit these PNGs by hand: re-export from the master if anything changes.

## The design

- **Background:** Ink `#05060B` square.
- **Mark:** the dark monogram (silver N with its dark folded facet, teal-gradient V arm, Signal Teal `#10F5D0` dot). The mark is wide (1.768:1), so it is scaled to **78 % of the square's width** and centred, then **raised by 2 %** of the side because the dot pulls the visual weight down-right (optical centring).
- **App-icon corners:** radius **18 %** of the side (92 px on a 512 px icon). Everything outside the corners is transparent.
- **Colours** come from `10_Color_and_Design_Tokens`: Ink `#05060B`, Silver ramp `#FFFFFF → #F5F7F8 → #AAB4BC`, dark facet `#2C3740 → #0E141A`, teal ramp `#087D9B → #00C9C8 → #18F2CF`, dot `#10F5D0`.

## Files

| File | Pixels | Corners / alpha | Purpose |
|---|---|---|---|
| `favicon.svg` | vector, viewBox 0 0 512 512 | rounded, transparent corners | Modern browsers (Chrome, Edge, Firefox, Opera). Monogram paths inlined verbatim from the master, ids re-prefixed `mvfav-` so it can be inlined next to other MV.tech SVGs. |
| `favicon.ico` | 16 + 32 + 48 in one file | rounded, transparent corners | Legacy browsers, Safari tab, link previews, crawlers. Frames are pixel-identical to `favicon-16/32/48.png`. |
| `favicon-16.png` … `favicon-256.png` | 16, 32, 48, 64, 96, 128, 256 | rounded, transparent corners | Explicit PNG favicons, bookmarks, RSS readers, browser extensions. |
| `apple-touch-icon-180.png` | 180 | **square, opaque** (RGB) | iOS / iPadOS home screen; iOS applies its own corner mask. |
| `android-chrome-192.png`, `android-chrome-512.png` | 192, 512 | rounded, transparent corners | Android / PWA icons (`purpose: any`) - install prompt, splash screen. |
| `android-chrome-maskable-512.png` | 512 | **square, opaque** (RGB) | Android adaptive icon (`purpose: maskable`). See safe zone below. |
| `mstile-150.png` | 150 | **square, opaque** (RGB) | Windows / Edge pinned-site tile; `TileColor` is Ink so the tile and the image merge. |
| `safari-pinned-tab.svg` | vector, viewBox 0 0 1200 678.72 (tight) | no background | Safari pinned tab / Touch Bar. Single-colour black silhouette; Safari tints it with the `color` attribute (`#071118` Navy in the snippet). |
| `site.webmanifest` | - | - | PWA manifest: name and short_name `MV.tech`, `theme_color` and `background_color` `#05060B`, the three android icons. |
| `browserconfig.xml` | - | - | Windows tile config pointing at `mstile-150.png`, TileColor `#05060B`. |
| `head-snippet.html` | - | - | The `<link>` / `<meta>` tags to paste into `<head>`. |

## Small sizes (16 and 32 px)

At 16 px the standard 78 % mark is 12.5 px wide and the dot is 1.4 px: it smears into the V arm. So, as is standard for favicons, the mark is **enlarged for the two smallest sizes only**:

| Size | Mark width | Why |
|---|---|---|
| 16 px (`favicon-16.png`, ico frame) | **92 %** | Only setting where the dot stays a separate teal pixel with a dark gap to the V arm. |
| 32 px (`favicon-32.png`, ico frame) | **86 %** | 78 % already reads; 86 % gives the dot a clear two-pixel separation and more tab presence. |
| 48 px and up, `favicon.svg` | 78 % | Standard composition. |

All small sizes were rendered at 8x by headless Chrome and downsampled with a Lanczos filter, then inspected at 8x nearest-neighbour zoom on white and on dark: the N, the V and the dot read as three separate elements at both 16 and 32 px. Browsers that use `favicon.svg` render the standard 78 % composition at whatever size they need.

## Maskable icon (Android adaptive)

Android may crop `purpose: maskable` icons to a circle, squircle or rounded square. The W3C safe zone is a **circle of radius 40 % of the side** centred on the icon. Because the monogram is wide, its top-left, top-right and bottom-left corners are the first points to leave that circle, so in `android-chrome-maskable-512.png` the mark is reduced to **66 % of the width** (raised 1.5 %): its furthest point sits 198 px from the centre against a 204.8 px safe radius (6.8 px margin). The icon is fully opaque so no mask shape ever reveals transparency.

## Installing on a site

1. Copy every file in this folder to the web root. `favicon.ico` and `favicon.svg` must stay at the root - browsers and link-preview bots request `/favicon.ico` without being told.
2. Paste the contents of `head-snippet.html` into `<head>`. Adjust paths only if you move the files.
3. If the files move, update the paths inside `site.webmanifest` and `browserconfig.xml` as well.

## Rules

- Icons always use the **dark monogram on Ink**. Never put the light (Navy) monogram or the wordmark on an icon; at these sizes only the monogram survives.
- Do not recolour the dot, change the gradient, add a border or a drop shadow, or rotate the mark.
- Do not upscale a small PNG to make a larger one. Re-export from `../00_Master_Vector/` instead (render the SVG at 8x the target with a browser engine, downsample with Lanczos).
- Need a square avatar for LinkedIn, GitHub or Slack? Use `../08_Social_Profile_Avatars/`, not these files.

## How these were verified

- Every PNG opened with Pillow: pixel size equals the size in the file name; rounded files are RGBA with alpha 0 at all four corners from 32 px up (at 16 px the 2.9 px corner radius part-covers the corner pixel, alpha about 14/255, which is correct) and 255 across the body; the three square files are RGB with no alpha channel; the background pixel is Ink `#05060B`.
- `favicon.ico` reopened with Pillow: frame set is exactly {16, 32, 48} and each frame is pixel-identical to the matching `favicon-NN.png`.
- `favicon.svg` and `safari-pinned-tab.svg` parsed with lxml: no `<image>`, `<text>` or foreign objects, unique ids, every gradient reference resolves; the pinned-tab file contains only `#000000` fills.
- `favicon.svg` rendered by Chrome at 512 px matches `android-chrome-512.png` (same geometry, different rasteriser path) within anti-aliasing tolerance.
- A contact sheet of every icon at 1x on a white strip and on a dark strip, plus 8x zooms of the 16/32/48 px files, was inspected visually.
