# 02_Horizontal — horizontal lockup (monogram + wordmark) — PNG / WebP / JPG exports

Monogram and `MV.tech` wordmark side by side, no descriptor or slogan. The workhorse logo: website header, email signature, slide footers, invoices, co-branding bars, social banners.

**Minimum size: 160 px wide on screen / 35 mm wide in print.** Below that, use `04_Monogram` (min 24 px). The 128 px files are for thumbnails and previews only.

**Naming:** `mvtech-horizontal-<variant>-<width>.png`. The number is the exact **pixel width**; height follows the master's aspect ratio (transparent files 4443.54 : 1000 ≈ 4.4 : 1, safe versions 4848.71 : 1405.17 ≈ 3.45 : 1 because they include the clear space). The 8000 px safe versions are for print and large-format use.

## Which file do I use?

| Surface you are placing the logo on | Use | Notes |
|---|---|---|
| Ink (#05060B), navy, photos, any **dark** surface | `…-dark-<size>.png` / `.webp` | Silver artwork + teal V arm, **transparent** background |
| White, Silver (#F4F6F8), any **white or pale** surface | `…-light-<size>.png` / `.webp` | Navy (#071118) artwork + teal V arm, **transparent** background |
| You cannot control the background (slides, docs, partner sites, marketplaces) | `…-dark-on-ink-<size>.png` or `…-light-on-white-<size>.png` | **Safe versions**: background and clear space are baked in. When unsure, use these. |
| One-colour production (engraving, embossing, fax, watermark) | `06_Monochrome/…-mono-black` or `…-mono-white` | Every region incl. the dot in one colour |

> **The transparent `-dark-…` files look empty in a white file browser / Finder / Explorer preview.** Nothing is missing — the artwork is silver and white on a transparent background. Drop the file onto a dark surface (or open the matching `-dark-on-ink-` file) to see it.

## Formats
- **PNG** — every size; RGBA (transparent) for `dark`/`light`, RGB (opaque) for the `-on-ink`/`-on-white` safe versions.
- **WebP (lossless)** — `dark`/`light` at 512, 1024 and 2048, pixel-identical to the PNGs, ~2–3× smaller. Use on the web.
- **JPG (quality 92)** — `-on-ink`/`-on-white` at 2048 only, for tools that refuse PNG (some CRMs, ad platforms, directory listings). JPG cannot be transparent, which is why only the safe versions exist as JPG.

## Rules (from the brand guidelines)
- Clear space: keep one **dot diameter** free on every side of the transparent files. The `-on-ink`/`-on-white` files already include it — do not add more padding around them, and do not crop it away.
- Never stretch, rotate, recolour, outline, add shadows/glows, change the gradient, or separate the dot from the mark. Never retype "MV.tech" in a font.
- Need a size that is not here, a print file, or EPS/AI? Use the true-vector masters in `../00_Master_Vector/` — every file in this folder is exported from them.

## Inventory (34 files)
| File | Pixels (W×H) | Mode | Size |
|---|---|---|---|
| `mvtech-horizontal-dark-1024.png` | 1024×230 | transparent | 32 KB |
| `mvtech-horizontal-dark-1024.webp` | 1024×230 | transparent | 17 KB |
| `mvtech-horizontal-dark-128.png` | 128×29 | transparent | 2 KB |
| `mvtech-horizontal-dark-2048.png` | 2048×461 | transparent | 102 KB |
| `mvtech-horizontal-dark-2048.webp` | 2048×461 | transparent | 34 KB |
| `mvtech-horizontal-dark-256.png` | 256×58 | transparent | 5 KB |
| `mvtech-horizontal-dark-4096.png` | 4096×922 | transparent | 302 KB |
| `mvtech-horizontal-dark-512.png` | 512×115 | transparent | 12 KB |
| `mvtech-horizontal-dark-512.webp` | 512×115 | transparent | 8 KB |
| `mvtech-horizontal-dark-on-ink-1024.png` | 1024×297 | opaque | 29 KB |
| `mvtech-horizontal-dark-on-ink-128.png` | 128×37 | opaque | 2 KB |
| `mvtech-horizontal-dark-on-ink-2048.jpg` | 2048×594 | opaque | 73 KB |
| `mvtech-horizontal-dark-on-ink-2048.png` | 2048×594 | opaque | 84 KB |
| `mvtech-horizontal-dark-on-ink-256.png` | 256×74 | opaque | 5 KB |
| `mvtech-horizontal-dark-on-ink-4096.png` | 4096×1187 | opaque | 256 KB |
| `mvtech-horizontal-dark-on-ink-512.png` | 512×148 | opaque | 11 KB |
| `mvtech-horizontal-dark-on-ink-8000.png` | 8000×2318 | opaque | 677 KB |
| `mvtech-horizontal-light-1024.png` | 1024×230 | transparent | 19 KB |
| `mvtech-horizontal-light-1024.webp` | 1024×230 | transparent | 10 KB |
| `mvtech-horizontal-light-128.png` | 128×29 | transparent | 2 KB |
| `mvtech-horizontal-light-2048.png` | 2048×461 | transparent | 60 KB |
| `mvtech-horizontal-light-2048.webp` | 2048×461 | transparent | 22 KB |
| `mvtech-horizontal-light-256.png` | 256×58 | transparent | 4 KB |
| `mvtech-horizontal-light-4096.png` | 4096×922 | transparent | 178 KB |
| `mvtech-horizontal-light-512.png` | 512×115 | transparent | 8 KB |
| `mvtech-horizontal-light-512.webp` | 512×115 | transparent | 5 KB |
| `mvtech-horizontal-light-on-white-1024.png` | 1024×297 | opaque | 17 KB |
| `mvtech-horizontal-light-on-white-128.png` | 128×37 | opaque | 2 KB |
| `mvtech-horizontal-light-on-white-2048.jpg` | 2048×594 | opaque | 73 KB |
| `mvtech-horizontal-light-on-white-2048.png` | 2048×594 | opaque | 49 KB |
| `mvtech-horizontal-light-on-white-256.png` | 256×74 | opaque | 3 KB |
| `mvtech-horizontal-light-on-white-4096.png` | 4096×1187 | opaque | 152 KB |
| `mvtech-horizontal-light-on-white-512.png` | 512×148 | opaque | 7 KB |
| `mvtech-horizontal-light-on-white-8000.png` | 8000×2318 | opaque | 395 KB |
