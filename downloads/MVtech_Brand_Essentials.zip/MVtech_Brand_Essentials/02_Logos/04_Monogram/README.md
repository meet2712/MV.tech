# 04_Monogram — the MV mark alone — PNG / WebP / JPG exports

The angular monogram without the wordmark: silver (or navy) N + left V arm with the dark folded facet, teal right V arm, Signal Teal dot. For avatars, app icons, favicons, watermarks, bullet marks, and any space too small for a lockup. (Ready-made favicon/app-icon sets live in `../07_Favicons_and_App_Icons/`, social avatars in `../08_Social_Profile_Avatars/`.)

**Minimum size: 24 px tall on screen / 8 mm tall in print.** The 32 px and 64 px files are provided for UI icons and favicons; the 32 px file is the smallest export in which the dot and the facet still read (checked at 8× zoom). Note that in the 32 px and 64 px **safe versions** (`-on-ink`, `-on-white`) the file height includes the clear space, so the mark itself is only ~23 px / ~46 px tall — use the transparent 32/64 files when you need the mark to fill an icon slot, and let the host UI supply the background.

**Naming:** `mvtech-monogram-<variant>-<height>.png`. The number is the exact **pixel height**; width follows the master's aspect ratio (transparent files 1200 : 678.72 ≈ 1.77 : 1, safe versions 1475 : 953.72 ≈ 1.55 : 1). The safe versions were composed from the monogram master with a background and a clear-space margin of exactly one dot diameter (137.5 master units = 20.3 % of the mark height) on all sides.

## Which file do I use?

| Surface you are placing the logo on | Use | Notes |
|---|---|---|
| Ink (#05060B), navy, photos, any **dark** surface | `…-dark-<size>.png` / `.webp` | Silver artwork + teal V arm, **transparent** background |
| White, Silver (#F4F6F8), any **white or pale** surface | `…-light-<size>.png` / `.webp` | Navy (#071118) artwork + teal V arm, **transparent** background |
| You cannot control the background (slides, docs, partner sites, marketplaces) | `…-dark-on-ink-<size>.png` or `…-light-on-white-<size>.png` | **Safe versions**: background and clear space are baked in. When unsure, use these. |
| One-colour production (engraving, embossing, fax, watermark) | `06_Monochrome/…-mono-black` or `…-mono-white` | Every region incl. the dot in one colour |

> **The transparent `-dark-…` files look empty in a white file browser / Finder / Explorer preview.** Nothing is missing — the artwork is silver and white on a transparent background. Drop the file onto a dark surface (or open the matching `-dark-on-ink-` file) to see it.

## Formats
- **PNG** — every size; RGBA (transparent) for `dark`/`light`, RGB (opaque) for the `-on-ink`/`-on-white` safe versions.
- **WebP (lossless)** — `dark`/`light` at 512, 1024 and 2048, pixel-identical to the PNGs, ~2–3× smaller. Use on the web.
- **JPG (quality 92)** — `-on-ink`/`-on-white` at 2048 only, for tools that refuse PNG (some CRMs, ad platforms, directory listings). JPG cannot be transparent, which is why only the safe versions exist as JPG.

## Rules (from the brand guidelines)
- Clear space: keep one **dot diameter** free on every side of the transparent files. The `-on-ink`/`-on-white` files already include it — do not add more padding around them, and do not crop it away.
- Never stretch, rotate, recolour, outline, add shadows/glows, change the gradient, or separate the dot from the mark. Never retype "MV.tech" in a font.
- Need a size that is not here, a print file, or EPS/AI? Use the true-vector masters in `../00_Master_Vector/` — every file in this folder is exported from them.

## Inventory (40 files)
| File | Pixels (W×H) | Mode | Size |
|---|---|---|---|
| `mvtech-monogram-dark-1024.png` | 1810×1024 | transparent | 203 KB |
| `mvtech-monogram-dark-1024.webp` | 1810×1024 | transparent | 73 KB |
| `mvtech-monogram-dark-128.png` | 226×128 | transparent | 10 KB |
| `mvtech-monogram-dark-2048.png` | 3621×2048 | transparent | 566 KB |
| `mvtech-monogram-dark-2048.webp` | 3621×2048 | transparent | 160 KB |
| `mvtech-monogram-dark-256.png` | 453×256 | transparent | 28 KB |
| `mvtech-monogram-dark-32.png` | 57×32 | transparent | 2 KB |
| `mvtech-monogram-dark-4096.png` | 7242×4096 | transparent | 1,620 KB |
| `mvtech-monogram-dark-512.png` | 905×512 | transparent | 84 KB |
| `mvtech-monogram-dark-512.webp` | 905×512 | transparent | 33 KB |
| `mvtech-monogram-dark-64.png` | 113×64 | transparent | 4 KB |
| `mvtech-monogram-dark-on-ink-1024.png` | 1584×1024 | opaque | 147 KB |
| `mvtech-monogram-dark-on-ink-128.png` | 198×128 | opaque | 7 KB |
| `mvtech-monogram-dark-on-ink-2048.jpg` | 3167×2048 | opaque | 184 KB |
| `mvtech-monogram-dark-on-ink-2048.png` | 3167×2048 | opaque | 413 KB |
| `mvtech-monogram-dark-on-ink-256.png` | 396×256 | opaque | 17 KB |
| `mvtech-monogram-dark-on-ink-32.png` | 49×32 | opaque | 1 KB |
| `mvtech-monogram-dark-on-ink-4096.png` | 6335×4096 | opaque | 1,130 KB |
| `mvtech-monogram-dark-on-ink-512.png` | 792×512 | opaque | 48 KB |
| `mvtech-monogram-dark-on-ink-64.png` | 99×64 | opaque | 3 KB |
| `mvtech-monogram-light-1024.png` | 1810×1024 | transparent | 136 KB |
| `mvtech-monogram-light-1024.webp` | 1810×1024 | transparent | 38 KB |
| `mvtech-monogram-light-128.png` | 226×128 | transparent | 5 KB |
| `mvtech-monogram-light-2048.png` | 3621×2048 | transparent | 391 KB |
| `mvtech-monogram-light-2048.webp` | 3621×2048 | transparent | 85 KB |
| `mvtech-monogram-light-256.png` | 453×256 | transparent | 15 KB |
| `mvtech-monogram-light-32.png` | 57×32 | transparent | 1 KB |
| `mvtech-monogram-light-4096.png` | 7242×4096 | transparent | 1,020 KB |
| `mvtech-monogram-light-512.png` | 905×512 | transparent | 48 KB |
| `mvtech-monogram-light-512.webp` | 905×512 | transparent | 19 KB |
| `mvtech-monogram-light-64.png` | 113×64 | transparent | 3 KB |
| `mvtech-monogram-light-on-white-1024.png` | 1584×1024 | opaque | 85 KB |
| `mvtech-monogram-light-on-white-128.png` | 198×128 | opaque | 4 KB |
| `mvtech-monogram-light-on-white-2048.jpg` | 3167×2048 | opaque | 173 KB |
| `mvtech-monogram-light-on-white-2048.png` | 3167×2048 | opaque | 287 KB |
| `mvtech-monogram-light-on-white-256.png` | 396×256 | opaque | 9 KB |
| `mvtech-monogram-light-on-white-32.png` | 49×32 | opaque | 1 KB |
| `mvtech-monogram-light-on-white-4096.png` | 6335×4096 | opaque | 824 KB |
| `mvtech-monogram-light-on-white-512.png` | 792×512 | opaque | 28 KB |
| `mvtech-monogram-light-on-white-64.png` | 99×64 | opaque | 2 KB |
