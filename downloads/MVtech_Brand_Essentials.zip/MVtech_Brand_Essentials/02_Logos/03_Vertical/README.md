# 03_Vertical — stacked lockup (monogram above wordmark + descriptor + slogan) — PNG / WebP / JPG exports

Everything centred and stacked: monogram on top, `MV.tech`, then `DATA | AI | DIGITAL SOLUTIONS` and `SOLUTIONS THAT SCALE`. For square and portrait spaces: social posts, print covers, roll-up banners, app splash screens, badges.

**Minimum size.** The brand rules define minimums for the primary lockup (320 px / 55 mm) and the horizontal lockup (160 px / 35 mm) and the monogram (24 px / 8 mm); no separate number is set for the vertical lockup. Derived from the primary rule (the descriptor and slogan must be at least as large as in a 320 px primary lockup): keep the vertical lockup **at least ~165 px tall (~30 mm in print)**, i.e. use the 256 px export or larger. The 128 px files are for thumbnails and previews only.

**Naming:** `mvtech-vertical-<variant>-<height>.png`. For this family the number is the exact **pixel height** (the controlling dimension of a stacked logo); width follows the master's aspect ratio (transparent files 2174.38 : 1932.24 ≈ 1.125 : 1, safe versions 2579.55 : 2337.42 ≈ 1.10 : 1).

## Which file do I use?

| Surface you are placing the logo on | Use | Notes |
|---|---|---|
| Ink (#05060B), navy, photos, any **dark** surface | `…-dark-<size>.png` / `.webp` | Silver artwork + teal V arm, **transparent** background |
| White, Silver (#F4F6F8), any **white or pale** surface | `…-light-<size>.png` / `.webp` | Navy (#071118) artwork + teal V arm, **transparent** background |
| You cannot control the background (slides, docs, partner sites, marketplaces) | `…-dark-on-ink-<size>.png` or `…-light-on-white-<size>.png` | **Safe versions**: background and clear space are baked in. When unsure, use these. |
| One-colour production (engraving, embossing, fax, watermark) | `06_Monochrome/…-mono-black` or `…-mono-white` | Every region incl. the dot in one colour |

> **The transparent `-dark-…` files look empty in a white file browser / Finder / Explorer preview.** Nothing is missing — the artwork is silver and white on a transparent background. Drop the file onto a dark surface (or open the matching `-dark-on-ink-` file) to see it.

## Formats
- **PNG** — every size; RGBA (transparent) for `dark`/`light`, RGB (opaque) for the `-on-ink`/`-on-white` safe versions.
- **WebP (lossless)** — `dark`/`light` at 512, 1024 and 2048, pixel-identical to the PNGs, ~2–3× smaller. Use on the web.
- **JPG (quality 92)** — `-on-ink`/`-on-white` at 2048 only, for tools that refuse PNG (some CRMs, ad platforms, directory listings). JPG cannot be transparent, which is why only the safe versions exist as JPG.

## Rules (from the brand guidelines)
- Clear space: keep one **dot diameter** free on every side of the transparent files. The `-on-ink`/`-on-white` files already include it — do not add more padding around them, and do not crop it away.
- Never stretch, rotate, recolour, outline, add shadows/glows, change the gradient, or separate the dot from the mark. Never retype "MV.tech" in a font.
- Need a size that is not here, a print file, or EPS/AI? Use the true-vector masters in `../00_Master_Vector/` — every file in this folder is exported from them.

## Inventory (32 files)
| File | Pixels (W×H) | Mode | Size |
|---|---|---|---|
| `mvtech-vertical-dark-1024.png` | 1152×1024 | transparent | 117 KB |
| `mvtech-vertical-dark-1024.webp` | 1152×1024 | transparent | 44 KB |
| `mvtech-vertical-dark-128.png` | 144×128 | transparent | 7 KB |
| `mvtech-vertical-dark-2048.png` | 2305×2048 | transparent | 336 KB |
| `mvtech-vertical-dark-2048.webp` | 2305×2048 | transparent | 95 KB |
| `mvtech-vertical-dark-256.png` | 288×256 | transparent | 15 KB |
| `mvtech-vertical-dark-4096.png` | 4609×4096 | transparent | 810 KB |
| `mvtech-vertical-dark-512.png` | 576×512 | transparent | 40 KB |
| `mvtech-vertical-dark-512.webp` | 576×512 | transparent | 21 KB |
| `mvtech-vertical-dark-on-ink-1024.png` | 1130×1024 | opaque | 83 KB |
| `mvtech-vertical-dark-on-ink-128.png` | 141×128 | opaque | 6 KB |
| `mvtech-vertical-dark-on-ink-2048.jpg` | 2260×2048 | opaque | 219 KB |
| `mvtech-vertical-dark-on-ink-2048.png` | 2260×2048 | opaque | 230 KB |
| `mvtech-vertical-dark-on-ink-256.png` | 283×256 | opaque | 13 KB |
| `mvtech-vertical-dark-on-ink-4096.png` | 4520×4096 | opaque | 530 KB |
| `mvtech-vertical-dark-on-ink-512.png` | 565×512 | opaque | 30 KB |
| `mvtech-vertical-light-1024.png` | 1152×1024 | transparent | 72 KB |
| `mvtech-vertical-light-1024.webp` | 1152×1024 | transparent | 28 KB |
| `mvtech-vertical-light-128.png` | 144×128 | transparent | 5 KB |
| `mvtech-vertical-light-2048.png` | 2305×2048 | transparent | 222 KB |
| `mvtech-vertical-light-2048.webp` | 2305×2048 | transparent | 57 KB |
| `mvtech-vertical-light-256.png` | 288×256 | transparent | 10 KB |
| `mvtech-vertical-light-4096.png` | 4609×4096 | transparent | 585 KB |
| `mvtech-vertical-light-512.png` | 576×512 | transparent | 26 KB |
| `mvtech-vertical-light-512.webp` | 576×512 | transparent | 14 KB |
| `mvtech-vertical-light-on-white-1024.png` | 1130×1024 | opaque | 54 KB |
| `mvtech-vertical-light-on-white-128.png` | 141×128 | opaque | 4 KB |
| `mvtech-vertical-light-on-white-2048.jpg` | 2260×2048 | opaque | 224 KB |
| `mvtech-vertical-light-on-white-2048.png` | 2260×2048 | opaque | 146 KB |
| `mvtech-vertical-light-on-white-256.png` | 283×256 | opaque | 9 KB |
| `mvtech-vertical-light-on-white-4096.png` | 4520×4096 | opaque | 390 KB |
| `mvtech-vertical-light-on-white-512.png` | 565×512 | opaque | 19 KB |
