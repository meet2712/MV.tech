# MV.tech typography — Inter

Inter is the MV.tech brand typeface for everything digital: website, product UI, social graphics, PDFs and the descriptor/slogan lines in the logo lockups. Office documents use Arial (see *Office fallback policy*). The `MV.tech` wordmark itself is artwork — never retype it in Inter or any other font.

## What is in this folder

| Path | Contents |
|---|---|
| `Inter_Desktop_TTF/Inter-Regular.ttf` … `Inter-ExtraBold.ttf` | Five **true static** weights (400, 500, 600, 700, 800) for installing on macOS / Windows and for design apps. No variation tables at all, so Office, older apps and print RIPs treat them as ordinary TTFs. |
| `Inter_Desktop_TTF/Inter-Variable.ttf` | The variable font (weight axis 100–900, optical-size axis 14–32) — for apps that support variable fonts (Figma, Adobe CC, Affinity 2, browsers). |
| `Inter_Web_WOFF2/inter-latin-var.woff2` | Web font, variable weight 100–900, Latin subset, 73 KB (73,184 bytes). |
| `Inter_Type_Specimen.png` | 1600 × 1000 specimen of the shipped weights, the weight axis of the variable file, and the type roles. |
| `LICENSE-Inter-OFL.txt` | SIL Open Font License 1.1 — free to use, embed, bundle and redistribute with the kit. |

**Provenance.** The shipped TTFs are *Latin-subset instances* generated with fontTools from the OFL Inter 4.001 variable font (518 glyphs, 230 code points: Basic Latin, Latin-1, common punctuation, quotes, dashes, €/£, ™/©, arrows ↑↓). The five statics are fully instanced: the weight is baked in **and** the optical-size axis is pinned to Inter's text size (`opsz` 14), so the files carry no `fvar`/`STAT`/`gvar` tables and no app can accidentally re-vary them. If you want optical sizing to track the type size, use `Inter-Variable.ttf` instead — it keeps both axes (`wght` 100–900, `opsz` 14–32). All six faces and the WOFF2 carry the OFL licence in their name table (name IDs 13 and 14). For Cyrillic, Greek, Vietnamese, the full symbol set or italics, download the complete family from the Inter project: <https://rsms.me/inter> (same licence). Nothing in this kit was downloaded from the network.

**Font menu names.** Regular and Bold ship as family **Inter** (styles Regular and Bold), so the *B* button pairs them correctly in Word and on the web. Medium, SemiBold and ExtraBold are not part of that four-style set, so they ship the standard way: family **Inter Medium** / **Inter SemiBold** / **Inter ExtraBold** with typographic family `Inter` and typographic style `Medium` / `SemiBold` / `ExtraBold`. Word and PowerPoint therefore list them as separate families; Figma, Illustrator, InDesign and browsers group all five under *Inter*.

## Type roles

Sizes are desktop CSS px (use `rem` in code); mobile sizes in brackets. Headings are Bold/SemiBold, body Regular, labels uppercase and tracked — matching the brand guidelines.

| Role | Weight | Size / line-height | Tracking | Notes |
|---|---|---|---|---|
| Display | ExtraBold 800 | 56–72 / 1.05 (40) | −0.02em | Hero statements, cover slides |
| Heading 1 | Bold 700 | 40–48 / 1.10 (32) | −0.015em | Page / section titles |
| Heading 2 | SemiBold 600 | 28–32 / 1.20 (24) | −0.01em | |
| Heading 3 | SemiBold 600 | 20–22 / 1.30 | 0 | Card titles |
| Body | Regular 400 | 16–18 / 1.60 | 0 | Max ~70 characters per line |
| Body small / caption | Regular 400 | 13–14 / 1.50 | 0 | Slate on dark, Graphite on light |
| Label / eyebrow | Medium 500, UPPERCASE | 12–13 / 1.20 | 0.10–0.20em | Tags, table headers, nav |
| Button | SemiBold 600 | 15–16 / 1.00 | 0.01em | |
| **Descriptor** (lockup) | **Bold 700, UPPERCASE** | scales with the lockup | **0.28em** | `DATA \| AI \| DIGITAL SOLUTIONS` — pipes in Signal Teal on dark, System Cyan on light |
| **Slogan** (lockup) | **Medium 500, UPPERCASE** | scales with the lockup | **0.30em** | `SOLUTIONS THAT SCALE` |

Guidelines: never use weights below 400 for text (the variable font goes to 100 — Thin/Light are for oversized decorative numerals only). Prefer tabular figures (`tnum`) in tables and dashboards. Colour pairings live in `../10_Color_and_Design_Tokens/`.

## Installing the desktop fonts

Install **either** the five static TTFs **or** `Inter-Variable.ttf`, not both — the variable file uses the same family name *Inter* and the same PostScript name `Inter-Regular` as the static Regular, so the OS will report duplicates. The static set is the safe choice for Office and older apps; the variable file is best for Figma, Adobe CC and Affinity.

**macOS (Font Book)**
1. Open `Inter_Desktop_TTF/`, select the five `Inter-*.ttf` static files (or only `Inter-Variable.ttf`).
2. Double-click → *Install* in the preview window; or in Font Book choose *File → Add Fonts to Current User…* (use *Add Fonts to All Users* on shared Macs).
3. Font Book → *File → Validate Fonts* if it warns about duplicates, then restart the apps that should see the font.

**Windows 10 / 11**
1. Open `Inter_Desktop_TTF\`, select the five static `.ttf` files.
2. Right-click → **Install for all users** (needs administrator rights; use *Install* for the current user only if you have none).
3. Restart Office / Figma / browsers. Windows 10 (1809+) and 11 render the variable TTF too, but Office may not; install the static set for Office use.

**Linux**: copy the TTFs to `~/.local/share/fonts/` and run `fc-cache -f`.

## Office fallback policy (Word, PowerPoint, Outlook)

- The supplied Word, PowerPoint and email templates use **Arial** so they render identically on any machine without font installation. Do not change the template font to Inter for documents that leave the company.
- Use Inter in Office only when *everyone who will open or edit the file* has it installed (internal decks, printed PDFs). When exporting to PDF the font is embedded, so PDFs are always safe.
- If you must share an Inter-set `.docx`/`.pptx`, enable *File → Options → Save → Embed fonts in the file* (Windows) — the OFL permits embedding. Otherwise Office silently substitutes Calibri/Arial and the layout will shift.
- Email signatures: Arial only (HTML email cannot load web fonts reliably).

## Web

Serve `inter-latin-var.woff2` from your own domain (do not hot-link). Because the file is a Latin subset, keep the `unicode-range` so browsers fall back cleanly for other scripts.

```css
@font-face {
  font-family: "Inter";
  src: url("/fonts/inter-latin-var.woff2") format("woff2") tech(variations),
       url("/fonts/inter-latin-var.woff2") format("woff2-variations");
  font-weight: 100 900;
  font-style: normal;
  font-display: swap;
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC,
                 U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+2000-206F, U+20AC,
                 U+2122, U+2191, U+2193, U+2212, U+FEFF;
}

:root {
  --font-sans: "Inter", ui-sans-serif, system-ui, Arial, sans-serif;
}

body {
  font-family: var(--font-sans);
  font-feature-settings: "calt";               /* contextual alternates on */
  -webkit-font-smoothing: antialiased;
}

.descriptor { font-weight: 700; text-transform: uppercase; letter-spacing: 0.28em; }
.slogan     { font-weight: 500; text-transform: uppercase; letter-spacing: 0.30em; }
.label      { font-weight: 500; text-transform: uppercase; letter-spacing: 0.12em; }
table, .tabular { font-variant-numeric: tabular-nums; } /* tnum */
```

Fallback stack when Inter is not loaded: `ui-sans-serif, system-ui, Arial, sans-serif` (macOS/iOS → San Francisco, Windows → Segoe UI, then Arial). Available OpenType features in this subset: `calt`, `kern`, `tnum`, `pnum`, `frac`, `numr`, `dnom`, `ccmp`, `locl`.

## Licence

Inter is © The Inter Project Authors (<https://github.com/rsms/inter>), licensed under the SIL Open Font License 1.1 (`LICENSE-Inter-OFL.txt`, and recorded inside every shipped font file as name IDs 13/14 pointing at <https://openfontlicense.org>). You may use, embed, modify and redistribute it, including commercially; the fonts may not be sold on their own, and the OFL text must accompany any redistribution — keep the licence file next to the fonts.
