# Applying the MV.tech theme colours in PowerPoint and Word

Office documents pick their colours from a **theme colour scheme** of 12 slots. Applying the MV.tech scheme makes every shape, chart, table style and text-colour picker offer the brand palette (plus Office's automatic tints and shades) instead of the default blues.

## The 12 slots

| Office slot | Customize-Colors label | MV.tech colour | Hex |
|---|---|---|---|
| dk1 | Text/Background – Dark 1 | Navy | `071118` |
| lt1 | Text/Background – Light 1 | White | `FFFFFF` |
| dk2 | Text/Background – Dark 2 | Ink | `05060B` |
| lt2 | Text/Background – Light 2 | Silver | `F4F6F8` |
| accent1 | Accent 1 | Signal Teal | `10F5D0` |
| accent2 | Accent 2 | System Cyan | `00BFCB` |
| accent3 | Accent 3 | Deep Teal | `087D9B` |
| accent4 | Accent 4 | Teal Ink | `007E7B` |
| accent5 | Accent 5 | Slate | `8DA0B5` |
| accent6 | Accent 6 | Graphite | `405466` |
| hlink | Hyperlink | Teal Ink | `007E7B` |
| folHlink | Followed Hyperlink | Deep Teal | `087D9B` |

The same values are in `mvtech-office-theme-colors.xml`.

## Option A — enter the colours once (Windows and macOS)

**PowerPoint**
1. Open a presentation (ideally the MV.tech `.potx` template from `04_Presentation/`).
2. *Design* tab → in the *Variants* group click the small **More ▾** arrow → **Colors → Customize Colors…**
3. For each of the 12 rows click the swatch → **More Colors… → Custom** (Windows) / the colour wheel's **RGB Sliders** (macOS) → paste the hex value from the table.
4. Set *Name* to **MV.tech** and click **Save**. The scheme is now applied to this file and listed under *Design → Colors* for every future file.

**Word**
1. *Design* tab → **Colors → Customize Colors…** and follow the same steps 3–4.

**Outlook (HTML email)** uses Word's engine: *Options → Themes → Colors* once a message is open.

## Option B — install the XML file

PowerPoint and Word store custom schemes as plain XML files. Copy `mvtech-office-theme-colors.xml`, rename it to `MV.tech.xml`, place it in the folder below and restart Office. "MV.tech" then appears under *Design → Colors*.

| Platform | Folder |
|---|---|
| Windows | `%AppData%\Microsoft\Templates\Document Themes\Theme Colors\` |
| macOS | `~/Library/Group Containers/UBF8T346G9.Office/User Content.localized/Themes.localized/Theme Colors/` |

(Create the folder if it does not exist. If Office does not list the scheme, use Option A once — Office then creates the folder — and copy the file again.)

## Option C — for developers / template maintainers

Inside a `.pptx` / `.potx` / `.docx` / `.dotx` package (a zip), open `ppt/theme/theme1.xml` (Word: `word/theme/theme1.xml`) and replace the existing `<a:clrScheme>…</a:clrScheme>` element with the one from `mvtech-office-theme-colors.xml` (without the XML comment). Every slide and style bound to theme colours updates automatically.

## Google Slides / Docs

*Slide → Edit theme → Colors* (Slides) or the colour picker → **+ Custom** (Docs). Google offers the same 12-slot theme: paste the hex values from the table into *Text and background 1–4*, *Accent 1–6*, *Link*.

## Usage reminders

- Body text on white: Navy (Dark 1) or Graphite (Accent 6). Links: Teal Ink (Hyperlink).
- Signal Teal and System Cyan on white are decorative only — use them for shapes, rules and chart fills, never for body text.
- On Ink or Navy slides use White/Silver text with Slate for secondary text; Signal Teal for highlights.
- Templates ship in Arial for portability; see `../09_Fonts/FONT_GUIDE.md` before switching a deck to Inter.
