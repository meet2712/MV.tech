#!/usr/bin/env python3
"""build_tokens.py — the generator for MV.tech's colour and design tokens.

One source table (TOKENS below) produces every machine-readable export in
10_Color_and_Design_Tokens/. Change a value here, re-run, and all of them update together.

    cd 10_Color_and_Design_Tokens/_source
    python3 build_tokens.py

Requirements: Python 3.8+ only. No third-party packages.

The gradient tokens are not typed in here at all: on every run their stop colours, stop
positions and gradient vectors are read straight out of the monogram master,
02_Logos/00_Master_Vector/mvtech-monogram-dark.svg, so a published gradient can never drift
away from the artwork it documents. GRADIENT_SPEC below only names them and says where each
one sits in the mark; if the mark gains, loses or renames a gradient the build stops until
GRADIENT_SPEC is brought back in line. mvtech.ase is likewise parsed back after it is written.
Read the lines the script prints.

Writes, into the parent folder (10_Color_and_Design_Tokens/):
    mvtech-palette.json              master data (hex/rgb/hsl/cmyk~/WCAG contrast/gradients)
    tokens.w3c.json                  W3C Design Tokens (Figma Tokens Studio, Style Dictionary)
    mvtech-colors.css                CSS custom properties + semantic aliases + themes
    mvtech-colors.scss               Sass variables and maps
    tailwind.colors.cjs              Tailwind colors / backgroundImage / semantic
    mvtech-office-theme-colors.xml   DrawingML <a:clrScheme> for Word & PowerPoint
    mvtech.gpl                       GIMP / Inkscape / Krita palette
    mvtech.ase                       Adobe Swatch Exchange (verified by re-parsing it)

and, into this _source/ folder:
    MVtech_Color_Swatches.html       the swatch-sheet layout (Inter is loaded from 09_Fonts)

The two swatch-sheet exports are rendered from that HTML with headless Chrome — the script
prints the exact commands when it finishes:
    MVtech_Color_Swatches.png        1920 x 1080 screenshot
    MVtech_Color_Swatches.pdf        A4 landscape (the @page rule in the HTML sets the size)

README.md and PowerPoint_Theme_Colors_How_To.md in the parent folder are written by hand and
are NOT generated here — update them yourself when a value or a file changes.
"""
import json, struct, colorsys, os, datetime, math, sys

HERE = os.path.dirname(os.path.abspath(__file__))          # .../10_Color_and_Design_Tokens/_source
OUT = os.path.dirname(HERE)                                # .../10_Color_and_Design_Tokens
KIT = os.path.dirname(OUT)                                 # .../mvtech_brand_kit_v2
FONTS = os.path.join(KIT, "09_Fonts", "Inter_Desktop_TTF")  # Inter-Regular.ttf ... Inter-ExtraBold.ttf
TODAY = datetime.date.today().isoformat()

# ---------------------------------------------------------------- source table
# key, kebab, name, hex, cmyk~, role, usage rule
TOKENS = [
 ("ink",      "ink",       "Ink",         "#05060B", (55,45,0,96), "Primary dark background",
  "Default dark canvas for the brand. Pair with White, Silver, Signal Teal, System Cyan or Slate text."),
 ("navy",     "navy",      "Navy",        "#071118", (71,29,0,91), "Text; the mark on light backgrounds",
  "Primary body-text colour on white. Flat fill for the monogram body on light backgrounds."),
 ("teal",     "teal",      "Signal Teal", "#10F5D0", (93,0,15,4),  "Primary accent, dot, highlights on dark",
  "The teal dot and highlights on dark. Decorative only on white (fails AA for text)."),
 ("cyan",     "cyan",      "System Cyan", "#00BFCB", (100,6,0,20), "Gradient support; accent separators on light",
  "Mid stop of the teal ramp; separator pipes and rules on light. Decorative only on white."),
 ("deepTeal", "deep-teal", "Deep Teal",   "#087D9B", (95,19,0,39), "Gradient start (dark end of teal ramp)",
  "Start of the teal ramp and followed-link colour in Office. Not a text colour on white."),
 ("tealInk",  "teal-ink",  "Teal Ink",    "#007E7B", (100,0,2,51), "ONLY teal allowed for text/links on white (4.9:1 AA)",
  "Links and teal text on white or silver. Use instead of Signal Teal whenever the teal must be read."),
 ("silver",   "silver",    "Silver",      "#F4F6F8", (2,1,0,3),    "Light mark, light surfaces",
  "Monogram body on dark backgrounds; light surfaces, cards and table stripes on white."),
 ("slate",    "slate",     "Slate",       "#8DA0B5", (22,12,0,29), "Secondary text on dark (7.6:1) - NOT for text on white (2.7:1)",
  "Secondary and caption text on Ink or Navy. Never use for text on white or silver."),
 ("graphite", "graphite",  "Graphite",    "#405466", (37,18,0,60), "Secondary text on light (7.8:1)",
  "Secondary text, captions and UI labels on white or silver."),
 ("mist",     "mist",      "Mist",        "#718394", (24,11,0,42), "Tertiary/caption text on light (3.9:1, large only)",
  "Tertiary text on white at 18px+ (or 14px bold) only; placeholders, dividers, disabled states."),
 ("white",    "white",     "White",       "#FFFFFF", (0,0,0,0),    "Paper",
  "Paper and the default light canvas. Primary text colour on Ink."),
]

# The gradients ARE the fills of the monogram master. Their stop colours, stop positions and
# gradient vectors are READ OUT OF that SVG on every run - never typed here - so a token can
# never drift away from the artwork it documents. This table only says which gradient in the
# mark each token is, what to call it, the angle to use in UI work, and what it is in the mark.
# A gradient in the mark that is missing from this table is a build error.
# key, kebab, name, gradient id in the master, UI angle (None = the angle it has in the mark),
# what it is (short, for the swatch sheet), what it is (long)
MONO = "02_Logos/00_Master_Vector/mvtech-monogram-dark.svg"
GRADIENT_SPEC = [
 ("tealRamp", "teal-ramp", "Teal ramp", "mvm-dark-grad-teal", "45deg",
  "Right arm of the V",
  "The right arm of the V in the monogram: Deep Teal at the bottom-left to bright teal at the "
  "top-right. The end stop may be substituted with token teal #10F5D0."),
 ("silverRamp", "silver-ramp", "Silver ramp", "mvm-dark-grad-silver", "180deg",
  "Monogram body: N + left arm of the V",
  "The silver body of the monogram - the N and the left arm of the V - on dark backgrounds. It "
  "runs corner to corner across the whole mark, not per path."),
 ("facet", "facet", "Facet", "mvm-dark-grad-facet", None,
  "Lit face of the fold on the N's left leg",
  "The lit face of the fold on the N's left leg: near-black where the fold starts at the top, "
  "lightening to near-white at the foot. This is what gives the leg its three-dimensional turn."),
 ("fold", "fold", "Fold", "mvm-dark-grad-fold", None,
  "Dark triangle at the foot of the leg",
  "The dark triangle at the foot of the N's left leg, where the leg folds back under itself and "
  "the facet turns away from the light."),
]
# Note: the stop colours inside these gradients are gradient-only. They are not standalone
# palette tokens and must not be used as flat fills, text or UI colours.

# ---------------------------------------------------------------- colour maths
def hex_to_rgb(h): h=h.lstrip('#'); return tuple(int(h[i:i+2],16) for i in (0,2,4))
def rgb_to_hsl(rgb):
    r,g,b=[c/255 for c in rgb]; h,l,s=colorsys.rgb_to_hls(r,g,b)
    return (round(h*360), round(s*100), round(l*100))
def lum(rgb):
    def ch(c):
        c=c/255; return c/12.92 if c<=0.03928 else ((c+0.055)/1.055)**2.4
    r,g,b=rgb; return 0.2126*ch(r)+0.7152*ch(g)+0.0722*ch(b)
def ratio(a,b):
    la,lb=lum(a),lum(b); return (max(la,lb)+0.05)/(min(la,lb)+0.05)
def classify(r):
    return {"ratio": round(r,2),
            "normal_text": "AAA" if r>=7 else "AA" if r>=4.5 else "Fail",
            "large_text":  "AAA" if r>=4.5 else "AA" if r>=3 else "Fail",
            "ui_components_and_graphics": "Pass" if r>=3 else "Fail"}
NUMWORD={1:"one",2:"two",3:"three",4:"four",5:"five",6:"six",7:"seven",8:"eight"}
def numword(n): return NUMWORD.get(n,str(n))
def css_angle(x1,y1,x2,y2):
    """CSS gradient angle (0deg = up, clockwise) of an SVG gradient vector (y grows downward)."""
    return round(math.degrees(math.atan2(x2-x1, -(y2-y1))) % 360)

WHITE=(255,255,255); INK=hex_to_rgb("#05060B")
colors={}
for key,kebab,name,hx,cmyk,role,usage in TOKENS:
    rgb=hex_to_rgb(hx)
    colors[key]={"name":name,"token":key,"kebab":kebab,"hex":hx,"rgb":list(rgb),"rgb_css":f"rgb({rgb[0]} {rgb[1]} {rgb[2]})",
                 "hsl":list(rgb_to_hsl(rgb)),"hsl_css":"hsl({}deg {}% {}%)".format(*rgb_to_hsl(rgb)),
                 "cmyk_approx":list(cmyk),"relative_luminance":round(lum(rgb),4),"role":role,"usage":usage,
                 "contrast":{"on_white":classify(ratio(rgb,WHITE)),"on_ink":classify(ratio(rgb,INK))}}
# ---------------------------------------------------------------- read the gradients out of the mark
def read_master_gradients():
    """Every <linearGradient> in the monogram master, by id: units, vector, view box, stops."""
    import re
    path=os.path.join(KIT,MONO)
    if not os.path.isfile(path):
        sys.exit(f"ERROR: {path} not found. The gradients are read from the monogram master; "
                 f"run this script from inside the kit so it can reach 02_Logos/.")
    svg=open(path).read()
    vb=[float(v) for v in re.search(r'viewBox="([^"]+)"',svg).group(1).split()]
    out={}
    for m in re.finditer(r'<linearGradient([^>]*)>(.*?)</linearGradient>', svg, re.S):
        attrs,body=m.group(1),m.group(2)
        gid=re.search(r'id="([^"]+)"',attrs).group(1)
        v={k:float(val) for k,val in re.findall(r'\b(x1|y1|x2|y2)="([^"]+)"',attrs)}
        um=re.search(r'gradientUnits="([^"]+)"',attrs)
        stops=[(c.upper(),round(float(o)*100,4))
               for o,c in re.findall(r'<stop offset="([^"]+)" stop-color="([^"]+)"',body)]
        if len(v)!=4 or not stops:
            sys.exit(f"ERROR: {gid} in {MONO} has no x1/y1/x2/y2 vector or no stops; this script only "
                     f"understands two-point userSpaceOnUse linear gradients.")
        out[gid]={"units":um.group(1) if um else "objectBoundingBox","vector":v,"view_box":vb,"stops":stops}
    return out

master_grads=read_master_gradients()
missing=[gid for _,_,_,gid,_,_,_ in GRADIENT_SPEC if gid not in master_grads]
extra=[gid for gid in master_grads if gid not in {s[3] for s in GRADIENT_SPEC}]
if missing or extra:
    if missing: print(f"ERROR: GRADIENT_SPEC names gradients the mark does not have: {missing}")
    if extra:   print(f"ERROR: the mark has gradients GRADIENT_SPEC does not cover: {extra}")
    sys.exit("Fix GRADIENT_SPEC (or the master) so the two agree, then re-run. "
             "Every fill in the mark must be a published token.")

gradients={}
for key,kebab,name,gid,ui_angle,short,use in GRADIENT_SPEC:
    m=master_grads[gid]; v=m["vector"]
    stops=m["stops"]
    # positions come back as floats; keep them integral when they are
    stops=[(c, int(p) if float(p).is_integer() else p) for c,p in stops]
    in_mark=f"{css_angle(v['x1'],v['y1'],v['x2'],v['y2'])}deg"
    angle=ui_angle or in_mark   # None in the spec = use the angle it has in the mark
    css=f"linear-gradient({angle}, "+", ".join(f"{c} {p}%" for c,p in stops)+")"
    tail=(f" {angle} in the mark and in UI." if in_mark==angle
          else f" Apply at {angle} in UI work; inside the mark the same stops run at {in_mark}.")
    gradients[key]={"name":name,"token":key,"kebab":kebab,"angle":angle,
                    "stops":[{"color":c,"position":p} for c,p in stops],"css":css,
                    "short":short,"use":use+tail,
                    "master":{"file":MONO,"gradient_id":gid,"gradient_units":m["units"],
                              "view_box":m["view_box"],
                              "vector":{k:v[k] for k in ("x1","y1","x2","y2")},
                              "angle_in_mark":in_mark}}
print("GRADIENTS READ FROM "+os.path.basename(MONO))
for k in gradients:
    g=gradients[k]
    print(f"  {g['name']:<12} {g['master']['gradient_id']:<22} {len(g['stops'])} stops, "
          f"{g['master']['angle_in_mark']} in the mark, {g['angle']} in UI")


# ---------- 1. mvtech-palette.json
palette={"brand":"MV.tech","version":"2.0","generated":TODAY,"color_space":"sRGB",
 "notes":["CMYK values are approximate conversions; the printer must confirm on a proof.",
          "Contrast ratios are WCAG 2.1 (relative-luminance) ratios. normal_text: AA >= 4.5, AAA >= 7. large_text (>= 18px regular or >= 14px bold): AA >= 3, AAA >= 4.5. UI components/graphics: >= 3.",
          "On white: body text = Navy or Graphite; links = Teal Ink. Signal Teal and System Cyan on white are decorative only.",
          "On Ink: White, Silver, Signal Teal, System Cyan and Slate all pass AAA.",
          "The four gradients are the fills of the monogram master (02_Logos/00_Master_Vector/mvtech-monogram-dark.svg); each one records the gradient vector it has inside the mark. Their stop colours (#F9FAFB, #EEF1F3, #9FA9B1) are gradient-only and are not palette tokens."],
 "colors":colors,"gradients":gradients}
with open(f"{OUT}/mvtech-palette.json","w") as f: json.dump(palette,f,indent=2); f.write("\n")

# ---------- 2. mvtech-colors.css
def var_lines():
    L=[]
    for k in colors:
        c=colors[k]; L.append(f"  --mv-{c['kebab']}: {c['hex']};")
    L.append("")
    for k in colors:
        c=colors[k]; L.append(f"  --mv-{c['kebab']}-rgb: {c['rgb'][0]} {c['rgb'][1]} {c['rgb'][2]};  /* rgb(var(--mv-{c['kebab']}-rgb) / .5) */")
    return "\n".join(L)
grad_lines="\n".join(f"  --gradient-{gradients[k]['kebab']}: {gradients[k]['css']};" for k in gradients)
# "teal ramp 29deg, silver ramp 119deg, ..." - the direction each one runs inside the mark
mark_angles=", ".join(f"{gradients[k]['name'].lower()} {gradients[k]['master']['angle_in_mark']}" for k in gradients)
mark_angles_short=" / ".join(gradients[k]['master']['angle_in_mark'] for k in gradients)
stop_only=sorted({s["color"] for k in gradients for s in gradients[k]["stops"]}
                 - {colors[c]["hex"] for c in colors})
stop_only_sample=", ".join(stop_only[:3])+" ..."
css=f"""/* MV.tech colour tokens v2 - generated {TODAY} by _source/build_tokens.py
   Raw tokens: --mv-<name>   Semantic aliases: --color-<role>   Gradients: --gradient-<name>
   Rules: on white use Navy/Graphite for text and Teal Ink for links; Signal Teal & System Cyan are decorative on white.
          On Ink use White/Silver for text, Slate for secondary text, Signal Teal for accents. */
:root {{
  color-scheme: light;
{var_lines()}

  /* gradients - the {numword(len(gradients))} fills of the monogram master, at the angle to use in UI work.
     Inside the mark the same stops run along the vectors recorded in mvtech-palette.json
     ({mark_angles}).
     Stop colours that are not palette tokens ({stop_only_sample}, {len(stop_only)} in all)
     exist only inside these gradients - never use them as flat fills, text or UI colours. */
{grad_lines}

  /* semantic aliases - light theme */
  --color-bg: var(--mv-white);
  --color-surface: var(--mv-silver);
  --color-text: var(--mv-navy);
  --color-text-muted: var(--mv-graphite);
  --color-text-subtle: var(--mv-mist);            /* 3.9:1 - large text only */
  --color-link: var(--mv-teal-ink);
  --color-accent: var(--mv-cyan);                 /* decorative: rules, separators, icons */
  --color-accent-soft: rgb(var(--mv-cyan-rgb) / 0.12);
  --color-border: rgb(var(--mv-slate-rgb) / 0.35);
  --color-focus-ring: var(--mv-teal-ink);
}}

[data-theme="dark"] {{
  color-scheme: dark;
  --color-bg: var(--mv-ink);
  --color-surface: var(--mv-navy);
  --color-text: var(--mv-white);
  --color-text-muted: var(--mv-slate);
  --color-text-subtle: var(--mv-slate);
  --color-link: var(--mv-teal);
  --color-accent: var(--mv-teal);
  --color-accent-soft: rgb(var(--mv-teal-rgb) / 0.14);
  --color-border: rgb(var(--mv-slate-rgb) / 0.22);
  --color-focus-ring: var(--mv-teal);
}}

/* follow the OS when no explicit data-theme is set */
@media (prefers-color-scheme: dark) {{
  :root:not([data-theme="light"]) {{
    color-scheme: dark;
    --color-bg: var(--mv-ink);
    --color-surface: var(--mv-navy);
    --color-text: var(--mv-white);
    --color-text-muted: var(--mv-slate);
    --color-text-subtle: var(--mv-slate);
    --color-link: var(--mv-teal);
    --color-accent: var(--mv-teal);
    --color-accent-soft: rgb(var(--mv-teal-rgb) / 0.14);
    --color-border: rgb(var(--mv-slate-rgb) / 0.22);
    --color-focus-ring: var(--mv-teal);
  }}
}}

/* minimal usage */
body {{ background: var(--color-bg); color: var(--color-text); }}
a {{ color: var(--color-link); }}
"""
open(f"{OUT}/mvtech-colors.css","w").write(css)

# ---------- 3. mvtech-colors.scss
scss=[f"// MV.tech colour tokens v2 - generated {TODAY} by _source/build_tokens.py",
      "// Usage: @use 'mvtech-colors' as mv;  color: mv.$mv-navy;  background: map-get(mv.$mvtech-colors, 'teal-ink');",""]
for k in colors:
    c=colors[k]; scss.append(f"$mv-{c['kebab']}: {c['hex']}; // {c['name']} - {c['role']}")
scss.append("")
scss.append("$mvtech-colors: (")
scss += [f"  '{colors[k]['kebab']}': $mv-{colors[k]['kebab']}," for k in colors]
scss.append(");")
scss.append("")
scss.append(f"// The {numword(len(gradients))} fills of the monogram master, at the angle to use in UI work. Inside the mark")
scss.append(f"// the same stops run at {mark_angles_short} - see mvtech-palette.json.")
for k in gradients:
    g=gradients[k]; scss.append(f"$mv-gradient-{g['kebab']}: {g['css']};")
scss.append("")
scss.append("$mvtech-gradients: (")
scss += [f"  '{gradients[k]['kebab']}': $mv-gradient-{gradients[k]['kebab']}," for k in gradients]
scss.append(");")
scss.append("")
scss.append("// Semantic aliases (light). Dark theme: bg $mv-ink, surface $mv-navy, text $mv-white, muted $mv-slate, link/accent $mv-teal.")
scss += ["$color-bg: $mv-white;","$color-surface: $mv-silver;","$color-text: $mv-navy;","$color-text-muted: $mv-graphite;",
         "$color-link: $mv-teal-ink;","$color-accent: $mv-cyan;","$color-accent-soft: rgba($mv-cyan, 0.12);",""]
open(f"{OUT}/mvtech-colors.scss","w").write("\n".join(scss))

# ---------- 4. tailwind.colors.cjs
tw=[f"// MV.tech colour tokens v2 for Tailwind CSS - generated {TODAY} by _source/build_tokens.py",
    "// tailwind.config.js:",
    "//   const mvtech = require('./tailwind.colors.cjs');",
    "//   module.exports = { theme: { extend: { colors: { mvtech: mvtech.colors }, backgroundImage: mvtech.backgroundImage } } };",
    "// Classes: bg-mvtech-ink  text-mvtech-navy  text-mvtech-teal-ink  border-mvtech-slate/30  bg-mvtech-teal-ramp",
    "'use strict';","","const colors = {"]
for k in colors:
    c=colors[k]; tw.append(f"  '{c['kebab']}': '{c['hex']}', // {c['name']} - {c['role']}")
tw.append("};"); tw.append("")
tw.append(f"// The {numword(len(gradients))} fills of the monogram master, at the angle to use in UI work. Inside the mark")
tw.append(f"// the same stops run at {mark_angles_short} - see mvtech-palette.json.")
tw.append("const backgroundImage = {")
for k in gradients:
    g=gradients[k]; tw.append(f"  'mvtech-{g['kebab']}': '{g['css']}',")
tw.append("};"); tw.append("")
tw.append("// Semantic tokens you may map onto your own theme keys")
tw.append("const semantic = {")
tw.append("  light: { bg: colors.white, surface: colors.silver, text: colors.navy, textMuted: colors.graphite, link: colors['teal-ink'], accent: colors.cyan },")
tw.append("  dark:  { bg: colors.ink, surface: colors.navy, text: colors.white, textMuted: colors.slate, link: colors.teal, accent: colors.teal },")
tw.append("};"); tw.append("")
tw.append("module.exports = { colors, backgroundImage, semantic };")
open(f"{OUT}/tailwind.colors.cjs","w").write("\n".join(tw)+"\n")

# ---------- 5. tokens.w3c.json  (Design Tokens Community Group format)
w3c={"mvtech":{
  "$description":f"MV.tech brand colour tokens v2 (generated {TODAY} by _source/build_tokens.py). Import with Tokens Studio for Figma or Style Dictionary.",
  "color":{"$type":"color"},
  "gradient":{"$type":"gradient"},
  "semantic":{"$type":"color","$description":"Role aliases. light = white canvas, dark = Ink canvas."}}}
for k in colors:
    c=colors[k]
    w3c["mvtech"]["color"][c["kebab"]]={"$value":c["hex"],"$description":f"{c['name']} - {c['role']}",
        "$extensions":{"solutions.mvtech":{"rgb":c["rgb"],"cmykApprox":c["cmyk_approx"],
            "contrastOnWhite":c["contrast"]["on_white"]["ratio"],"contrastOnInk":c["contrast"]["on_ink"]["ratio"]}}}
for k in gradients:
    g=gradients[k]
    w3c["mvtech"]["gradient"][g["kebab"]]={"$value":[{"color":s["color"],"position":s["position"]/100} for s in g["stops"]],
        "$description":g["use"],"$extensions":{"solutions.mvtech":{"cssAngle":g["angle"],"css":g["css"],"master":g["master"]}}}
sem={"light":{"bg":"white","surface":"silver","text":"navy","text-muted":"graphite","link":"teal-ink","accent":"cyan"},
     "dark":{"bg":"ink","surface":"navy","text":"white","text-muted":"slate","link":"teal","accent":"teal"}}
for theme,m in sem.items():
    w3c["mvtech"]["semantic"][theme]={k:{"$value":"{mvtech.color."+v+"}"} for k,v in m.items()}
with open(f"{OUT}/tokens.w3c.json","w") as f: json.dump(w3c,f,indent=2); f.write("\n")

# ---------- 6. mvtech.gpl
gpl=["GIMP Palette","Name: MV.tech","Columns: 6","# MV.tech brand palette v2 (sRGB). CMYK in the brand guide is approximate."]
for k in colors:
    c=colors[k]; r,g,b=c["rgb"]; gpl.append(f"{r:3d} {g:3d} {b:3d}\t{c['name']} ({c['hex']})")
open(f"{OUT}/mvtech.gpl","w").write("\n".join(gpl)+"\n")

# ---------- 7. mvtech.ase  (Adobe Swatch Exchange, ASEF 1.0)
def u16(s): return (s+"\0").encode("utf-16-be")
def ase_bytes(group="MV.tech"):
    blocks=[]
    nm=u16(group); body=struct.pack(">H",len(nm)//2)+nm
    blocks.append(struct.pack(">HI",0xC001,len(body))+body)              # group start
    for k in colors:
        c=colors[k]; nm=u16(f"{c['name']} {c['hex']}")
        r,g,b=[v/255 for v in c["rgb"]]
        body=struct.pack(">H",len(nm)//2)+nm+b"RGB "+struct.pack(">fff",r,g,b)+struct.pack(">H",0)  # 0 = global
        blocks.append(struct.pack(">HI",0x0001,len(body))+body)          # colour entry
    blocks.append(struct.pack(">HI",0xC002,0))                           # group end
    return b"ASEF"+struct.pack(">HH",1,0)+struct.pack(">I",len(blocks))+b"".join(blocks)
open(f"{OUT}/mvtech.ase","wb").write(ase_bytes())

def parse_ase(data):
    assert data[:4]==b"ASEF", "bad magic"
    major,minor,count=struct.unpack(">HHI",data[4:12]); pos=12; out=[]; groups=[]
    for _ in range(count):
        btype,blen=struct.unpack(">HI",data[pos:pos+6]); pos+=6
        body=data[pos:pos+blen]; pos+=blen
        if btype==0x0001:
            n=struct.unpack(">H",body[:2])[0]; name=body[2:2+2*n].decode("utf-16-be").rstrip("\0"); o=2+2*n
            model=body[o:o+4].decode("ascii"); o+=4
            nvals={"RGB ":3,"CMYK":4,"LAB ":3,"Gray":1}[model]
            vals=struct.unpack(">"+"f"*nvals,body[o:o+4*nvals]); o+=4*nvals
            ctype=struct.unpack(">H",body[o:o+2])[0]
            out.append({"name":name,"model":model,"values":vals,"type":ctype})
        elif btype==0xC001:
            n=struct.unpack(">H",body[:2])[0]; groups.append(body[2:2+2*n].decode("utf-16-be").rstrip("\0"))
        elif btype==0xC002: pass
        else: raise ValueError(f"unknown block {btype:#06x}")
    assert pos==len(data), "trailing bytes"
    return (major,minor),groups,out
ver,groups,entries=parse_ase(open(f"{OUT}/mvtech.ase","rb").read())
ok=True
for e,k in zip(entries,colors):
    c=colors[k]; rt=[round(v*255) for v in e["values"]]
    good = rt==c["rgb"] and e["model"]=="RGB " and e["type"]==0 and e["name"]==f"{c['name']} {c['hex']}"
    ok&=good; print(f"ASE {e['name']:<28} model={e['model']!r} type={e['type']} rgb={rt} {'OK' if good else 'MISMATCH'}")
print("ASE version",ver,"groups",groups,"entries",len(entries),"ALL OK" if ok and len(entries)==len(colors) else "FAIL")

# ---------- 8. mvtech-office-theme-colors.xml
slots=[("dk1","navy"),("lt1","white"),("dk2","ink"),("lt2","silver"),("accent1","teal"),("accent2","cyan"),("accent3","deepTeal"),
       ("accent4","tealInk"),("accent5","slate"),("accent6","graphite"),("hlink","tealInk"),("folHlink","deepTeal")]
header=f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<!--
  MV.tech theme colours (DrawingML clrScheme) - generated {TODAY}.
  Slots: dk1=Navy text, lt1=White background, dk2=Ink, lt2=Silver, accent1=Signal Teal, accent2=System Cyan,
         accent3=Deep Teal, accent4=Teal Ink, accent5=Slate, accent6=Graphite, hlink=Teal Ink, folHlink=Deep Teal.
  HOW TO APPLY
  A) Manually: PowerPoint > Design > Variants (More v) > Colors > Customize Colors... (Word: Design > Colors > Customize Colors...).
     Enter each hex below in the matching slot (Text/Background - Dark 1 = dk1, Light 1 = lt1, Dark 2 = dk2, Light 2 = lt2,
     Accent 1-6, Hyperlink = hlink, Followed Hyperlink = folHlink), name the scheme "MV.tech" and Save.
  B) As a file: save this XML as "MV.tech.xml" into your Office theme-colours folder and restart Office:
     Windows  %AppData%\\Microsoft\\Templates\\Document Themes\\Theme Colors\\
     macOS    ~/Library/Group Containers/UBF8T346G9.Office/User Content.localized/Themes.localized/Theme Colors/
     The scheme then appears under Design > Colors as "MV.tech".
  C) Developers: drop this <a:clrScheme> into ppt/theme/theme1.xml (or word/theme/theme1.xml) of a .pptx/.docx package,
     replacing the existing <a:clrScheme>. Full guide: PowerPoint_Theme_Colors_How_To.md
-->
"""
body=['<a:clrScheme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="MV.tech">']
for slot,tok in slots:
    body.append(f"  <a:{slot}>")
    body.append(f'    <a:srgbClr val="{colors[tok]["hex"][1:]}"/>')
    body.append(f"    <!-- {colors[tok]['name']} -->")
    body.append(f"  </a:{slot}>")
body.append("</a:clrScheme>")
xml=header+"\n".join(body)+"\n"
open(f"{OUT}/mvtech-office-theme-colors.xml","w").write(xml)
import xml.etree.ElementTree as ET
parsed=ET.fromstring(xml.encode("utf-8"))   # re-parse what we just wrote, comment and all
print("XML clrScheme children:",len(list(parsed)),"name=",parsed.get("name"))

# ---------- 9. swatch sheet HTML (rendered to PNG/PDF separately - commands printed below)
if not os.path.isdir(FONTS):
    print(f"WARNING: {FONTS} not found - the swatch sheet will fall back to Arial.", file=sys.stderr)
# relative to this _source/ folder, so the HTML renders the same on any machine
FONTS_REL = "../../09_Fonts/Inter_Desktop_TTF"
def ff(w,file): return f'@font-face{{font-family:"Inter";font-weight:{w};src:url("{FONTS_REL}/{file}") format("truetype")}}'
matrix_rows=["navy","graphite","mist","tealInk","deepTeal","cyan","teal","slate","silver","white"]
rules={"navy":"Body text on white","graphite":"Secondary text on white","mist":"Large text only on white","tealInk":"Links / teal text on white",
       "deepTeal":"Passes AA, but Teal Ink is the brand text teal","cyan":"Decorative on white; text on Ink","teal":"Decorative on white; accent on Ink",
       "slate":"Secondary text on Ink only","silver":"Surfaces; text on Ink","white":"Paper; text on Ink"}
def verdict(cl):
    n=cl["normal_text"]; l=cl["large_text"]
    if n in("AAA","AA"): return n,"pass"
    if l in("AAA","AA"): return "Large only","large"
    return "Fail","fail"
cards=""
for k in colors:
    c=colors[k]; dark = c["relative_luminance"]<0.02
    cards+=f'''<div class="card"><div class="sw{' swdark' if dark else ''}" style="background:{c['hex']}"></div>
<div class="cbody"><div class="cname">{c['name']}<span class="ckey">{c['kebab']}</span></div>
<div class="crow"><span>HEX</span><b>{c['hex']}</b></div>
<div class="crow"><span>RGB</span><b>{c['rgb'][0]} {c['rgb'][1]} {c['rgb'][2]}</b></div>
<div class="crow"><span>CMYK</span><b>{' '.join(map(str,c['cmyk_approx']))}</b></div>
<div class="crole">{c['role']}</div></div></div>\n'''
cards+='''<div class="card sem"><div class="semh">Semantic roles<span class="ckey" style="float:right;margin-top:5px">mvtech-colors.css</span></div>
<div class="semcols"><div><b>Light UI</b><span>bg <i>White</i></span><span>surface <i>Silver</i></span><span>text <i>Navy</i></span><span>muted <i>Graphite</i></span><span>link <i>Teal Ink</i></span><span>accent <i>System Cyan</i></span></div>
<div><b>Dark UI</b><span>bg <i>Ink</i></span><span>surface <i>Navy</i></span><span>text <i>White</i></span><span>muted <i>Slate</i></span><span>link <i>Signal Teal</i></span><span>accent <i>Signal Teal</i></span></div></div>
<div class="crole">--color-bg, --color-surface, --color-text, --color-text-muted, --color-link, --color-accent, --color-accent-soft</div></div>'''
grads=""
for k in gradients:
    g=gradients[k]
    stops=" &#8250; ".join(f"{s['color']} {s['position']}%" for s in g["stops"])
    mark=g["master"]["angle_in_mark"]
    ang=(f"{mark} in the mark and in UI" if mark==g["angle"] else f"{g['angle']} in UI, {mark} in the mark")
    grads+=f'''<div class="gcard"><div class="gbar" style="background:{g['css']}"></div><div class="ginfo">
<div class="gname">{g['name']}<span class="ckey">--gradient-{g['kebab']}</span></div>
<div class="gstops">{stops}<br>{g['short']} &middot; {ang}</div></div></div>\n'''
rows=""
for k in matrix_rows:
    c=colors[k]; w=c["contrast"]["on_white"]; i=c["contrast"]["on_ink"]; vw,cw=verdict(w); vi,ci=verdict(i)
    rows+=f'''<tr><td class="mname"><i style="background:{c['hex']}"></i>{c['name']}</td>
<td><div class="cell onwhite"><span class="aa" style="color:{c['hex']}">Aa</span><span class="ratio">{w['ratio']:.2f}:1</span><span class="pill {cw}">{vw}</span></div></td>
<td><div class="cell onink"><span class="aa" style="color:{c['hex']}">Aa</span><span class="ratio">{i['ratio']:.2f}:1</span><span class="pill {ci}">{vi}</span></div></td>
<td class="rule">{rules[k]}</td></tr>\n'''
html=f'''<!doctype html><html><head><meta charset="utf-8"><title>MV.tech colour swatches</title><style>
{ff(400,'Inter-Regular.ttf')}
{ff(500,'Inter-Medium.ttf')}
{ff(600,'Inter-SemiBold.ttf')}
{ff(700,'Inter-Bold.ttf')}
{ff(800,'Inter-ExtraBold.ttf')}
:root{{--ink:#05060B;--navy:#071118;--teal:#10F5D0;--cyan:#00BFCB;--silver:#F4F6F8;--slate:#8DA0B5;--mist:#718394;--white:#fff;
 --sw-h:72px;--row-h:26px;--gap:18px;--stage-h:1080px;--gbar-h:46px}}
*{{box-sizing:border-box;margin:0;padding:0}}
html,body{{background:var(--ink);width:1920px;height:1080px;overflow:hidden}}
body{{font-family:"Inter",Arial,sans-serif;color:var(--white);-webkit-font-smoothing:antialiased;font-feature-settings:"tnum"}}
.stage{{width:1920px;height:var(--stage-h);padding:42px 56px 38px;display:flex;flex-direction:column;justify-content:space-between;gap:var(--gap)}}
.hdr{{display:flex;justify-content:space-between;align-items:flex-end}}
.eyebrow{{font-weight:500;font-size:13px;letter-spacing:.2em;text-transform:uppercase;color:var(--slate)}}
.eyebrow b{{color:var(--teal);font-weight:500}}
h1{{font-weight:800;font-size:44px;letter-spacing:-.02em;line-height:1.05;margin-top:10px}}
.meta{{text-align:right;color:var(--slate);font-size:14px;line-height:1.5}} .meta b{{color:var(--silver);font-weight:600}}
.grid{{display:grid;grid-template-columns:repeat(6,1fr);gap:18px}}
.card{{background:var(--navy);border:1px solid rgba(141,160,181,.18);border-radius:12px;overflow:hidden}}
.sw{{height:var(--sw-h)}} .swdark{{box-shadow:inset 0 0 0 1px rgba(141,160,181,.35)}}
.cbody{{padding:12px 14px 13px}}
.cname{{font-weight:600;font-size:17px;display:flex;justify-content:space-between;align-items:baseline;margin-bottom:7px}}
.ckey{{font-weight:500;font-size:11px;letter-spacing:.06em;color:var(--teal)}}
.crow{{display:flex;justify-content:space-between;font-size:12.5px;color:var(--slate);line-height:1.55}} .crow b{{color:var(--silver);font-weight:500}}
.crole{{margin-top:6px;font-size:11.5px;line-height:1.35;color:var(--slate);min-height:30px}}
.sem{{padding:14px 14px 13px;border-style:dashed}} .semh{{font-weight:600;font-size:17px;margin-bottom:8px}} .semcols{{display:grid;grid-template-columns:1fr 1fr;gap:10px}} .semcols b{{display:block;font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--teal);font-weight:500;margin-bottom:4px}} .semcols span{{display:block;font-size:12px;color:var(--slate);line-height:1.5}} .semcols span i{{font-style:normal;color:var(--silver)}}
.bottom{{display:grid;grid-template-columns:640px 1fr;gap:28px;align-items:stretch}}
h2{{font-weight:600;font-size:15px;letter-spacing:.12em;text-transform:uppercase;color:var(--silver);margin-bottom:10px}}
h2 small{{color:var(--slate);letter-spacing:0;text-transform:none;font-weight:400;font-size:12.5px;margin-left:10px}}
.gcard{{background:var(--navy);border:1px solid rgba(141,160,181,.18);border-radius:10px;padding:8px 12px 8px 8px;margin-bottom:8px;display:flex;gap:14px;align-items:center}} .ginfo{{flex:1;min-width:0}}
.gbar{{width:180px;height:var(--gbar-h);border-radius:7px;flex:none}}
.gname{{font-weight:600;font-size:14.5px;display:flex;justify-content:space-between;align-items:baseline}}
.gstops{{font-size:11.5px;color:var(--slate);margin-top:3px;line-height:1.45}}
table{{width:100%;border-collapse:collapse}}
th{{text-align:left;font-weight:500;font-size:11.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--slate);padding:0 8px 6px 0;border-bottom:1px solid rgba(141,160,181,.25)}}
td{{height:var(--row-h);padding:2px 8px 2px 0;font-size:12.5px;vertical-align:middle;border-bottom:1px solid rgba(141,160,181,.10)}}
.mname{{font-weight:500;color:var(--silver);white-space:nowrap;width:120px}} .mname i{{display:inline-block;width:11px;height:11px;border-radius:3px;margin-right:8px;vertical-align:-1px;box-shadow:inset 0 0 0 1px rgba(141,160,181,.35)}}
.cell{{display:flex;align-items:center;gap:10px;border-radius:6px;padding:0 10px;height:calc(var(--row-h) - 5px);width:250px}}
.onwhite{{background:#fff}} .onink{{background:var(--ink);box-shadow:inset 0 0 0 1px rgba(141,160,181,.3)}}
.aa{{font-weight:600;font-size:14px;width:26px}}
.ratio{{color:var(--mist);font-weight:500;width:66px;font-size:12px}} .onink .ratio{{color:var(--slate)}}
.pill{{margin-left:auto;font-size:10.5px;font-weight:600;letter-spacing:.06em;padding:2px 7px;border-radius:99px;border:1px solid}}
.pill.pass{{color:#007E7B;border-color:#007E7B}} .onink .pill.pass{{color:var(--teal);border-color:var(--teal)}}
.pill.large{{color:#405466;border-color:#405466}} .onink .pill.large{{color:var(--slate);border-color:var(--slate)}}
.pill.fail{{color:#718394;border-color:rgba(113,131,148,.6)}} .onink .pill.fail{{color:var(--mist);border-color:rgba(113,131,148,.6)}}
.rule{{color:var(--slate);font-size:12px}}
.foot{{display:flex;justify-content:space-between;color:var(--mist);font-size:11.5px}}
@page{{size:297mm 210mm;margin:0}}
@media print{{html,body{{width:297mm;height:210mm}} :root{{--sw-h:130px;--row-h:36px;--gap:26px;--stage-h:1357px;--gbar-h:60px}} .stage{{zoom:0.58464}} .crole{{font-size:12.5px}} td{{font-size:13.5px}} .rule{{font-size:13px}} .gstops{{font-size:12.5px}} .gname{{font-size:16px}}}}
</style></head><body><div class="stage">
<div class="hdr"><div><div class="eyebrow">MV.tech <b>|</b> Brand Kit v2 <b>|</b> 10_Color_and_Design_Tokens</div><h1>Colour system</h1></div>
<div class="meta"><b>{len(colors)} tokens &middot; {len(gradients)} gradients</b><br>sRGB hex &middot; CMYK approximate (printer to confirm) &middot; WCAG 2.1 contrast</div></div>
<div><h2>Palette<small>name &middot; token &middot; HEX &middot; RGB &middot; CMYK~ &middot; role</small></h2><div class="grid">{cards}</div></div>
<div class="bottom"><div><h2>Gradients<small>the {numword(len(gradients))} fills of the monogram master</small></h2>{grads}</div>
<div><h2>Text contrast &amp; usage<small>ratio against White and against Ink &middot; AA 4.5+, AAA 7+, large text 3+</small></h2>
<table><thead><tr><th>Colour</th><th>On White #FFFFFF</th><th>On Ink #05060B</th><th>Brand rule</th></tr></thead><tbody>{rows}</tbody></table></div></div>
<div class="foot"><span>On white: body text Navy or Graphite, links Teal Ink; Signal Teal and System Cyan are decorative only.</span><span>On Ink: White, Silver, Signal Teal, System Cyan and Slate all pass AAA. &middot; mvtech.solutions</span></div>
</div></body></html>'''
open(f"{HERE}/MVtech_Color_Swatches.html","w").write(html)

# ---------- summary
print("\nCONTRAST SUMMARY (ratio on white / on ink)")
for k in colors:
    c=colors[k]; print(f"  {c['name']:<12} white {c['contrast']['on_white']['ratio']:5.2f} {c['contrast']['on_white']['normal_text']:<5} ink {c['contrast']['on_ink']['ratio']:5.2f} {c['contrast']['on_ink']['normal_text']}")
print("\nGRADIENTS")
for k in gradients:
    g=gradients[k]; print(f"  {g['name']:<12} {g['css']}   (in the mark: {g['master']['angle_in_mark']}, {g['master']['gradient_id']})")
print("\nwrote into", OUT)
for n in ["mvtech-palette.json","tokens.w3c.json","mvtech-colors.css","mvtech-colors.scss","tailwind.colors.cjs",
          "mvtech-office-theme-colors.xml","mvtech.gpl","mvtech.ase"]:
    print(f"  {n:<32} {os.path.getsize(os.path.join(OUT,n)):>7} bytes")
print(f"  _source/MVtech_Color_Swatches.html {os.path.getsize(os.path.join(HERE,'MVtech_Color_Swatches.html')):>7} bytes")
print("""
Both swatch-sheet exports are rendered from that one HTML with headless Chrome. The kit was
built with Playwright; Puppeteer takes the same options:

  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
  await page.goto('file://.../_source/MVtech_Color_Swatches.html');
  await page.screenshot({ path: '../MVtech_Color_Swatches.png' });                 // 1920x1080 PNG
  await page.pdf({ path: '../MVtech_Color_Swatches.pdf', printBackground: true,
                   preferCSSPageSize: true, margin: { top:0, right:0, bottom:0, left:0 } });

By hand: open the HTML in Chrome at a 1920x1080 viewport and screenshot it, then File > Print >
Save as PDF with Background graphics on (the @page rule already asks for 297x210 mm landscape,
and the print media query re-lays the sheet for that page).

Check afterwards: the PNG is exactly 1920x1080, and the PDF is one A4-landscape page whose
GRADIENTS column lists all """ + str(len(gradients)) + """ gradients.""")
