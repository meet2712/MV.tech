# MV.tech colour & design tokens

One palette, exported in every format the team needs. Every export in this folder is generated from the same source table by `_source/build_tokens.py`, so the values are identical everywhere. Colours are sRGB; the CMYK values are approximate conversions that the printer must confirm on a proof.

## The palette

| Token | Name | Hex | RGB | CMYK ~ | Role |
|---|---|---|---|---|---|
| `ink` | Ink | `#05060B` | 5 6 11 | 55 45 0 96 | Primary dark background |
| `navy` | Navy | `#071118` | 7 17 24 | 71 29 0 91 | Text; the mark on light backgrounds |
| `teal` | Signal Teal | `#10F5D0` | 16 245 208 | 93 0 15 4 | Primary accent, the dot, highlights on dark |
| `cyan` | System Cyan | `#00BFCB` | 0 191 203 | 100 6 0 20 | Gradient support; accent separators on light |
| `deep-teal` | Deep Teal | `#087D9B` | 8 125 155 | 95 19 0 39 | Gradient start (dark end of the teal ramp) |
| `teal-ink` | Teal Ink | `#007E7B` | 0 126 123 | 100 0 2 51 | The only teal for text/links on white (4.9:1 AA) |
| `silver` | Silver | `#F4F6F8` | 244 246 248 | 2 1 0 3 | Light mark, light surfaces |
| `slate` | Slate | `#8DA0B5` | 141 160 181 | 22 12 0 29 | Secondary text on dark (7.6:1) — not for text on white (2.7:1) |
| `graphite` | Graphite | `#405466` | 64 84 102 | 37 18 0 60 | Secondary text on light (7.8:1) |
| `mist` | Mist | `#718394` | 113 131 148 | 24 11 0 42 | Tertiary text on light (3.9:1 — large text only) |
| `white` | White | `#FFFFFF` | 255 255 255 | 0 0 0 0 | Paper |

**Contrast rules.** On white: body text Navy or Graphite, links Teal Ink; Signal Teal and System Cyan are decorative only (they fail AA for text). On Ink: White, Silver, Signal Teal, System Cyan and Slate all pass AAA. Full WCAG ratios for every colour against white and against Ink are in `mvtech-palette.json` and on the swatch sheet.

## The gradients

There are four, and they are not decoration: they are the four fills of the monogram master, `02_Logos/00_Master_Vector/mvtech-monogram-dark.svg`. The stops below are copied from that file verbatim, so the mark can be rebuilt from these tokens alone. Apply the *UI angle* in design and web work; the *in the mark* angle is the direction the same stops run inside the artwork (recorded per gradient, with the gradient vector, in `mvtech-palette.json`).

| Token | Stops | UI angle | In the mark | Where it is in the mark |
|---|---|---|---|---|
| `--gradient-teal-ramp` | `#087D9B` 0% → `#00C9C8` 55% → `#18F2CF` 100% | 45° | 29° | The right arm of the V. The end stop may be substituted with token teal `#10F5D0`. |
| `--gradient-silver-ramp` | `#FFFFFF` 0% → `#F9FAFB` 35% → `#F5F7F8` 60% → `#AAB4BC` 100% | 180° | 119° | The monogram body — the N and the left arm of the V — on dark backgrounds. |
| `--gradient-dark-facet` | `#2C3740` 0% → `#0E141A` 100% | 180° | 160° | The folded facet at the foot of the N's left leg. |
| `--gradient-fold-wedge` | `#EEF1F3` 0% → `#9FA9B1` 100% | 180° | 180° | The shaded fold triangle on the N's left edge, against the dark facet — it is what makes the fold read as three-dimensional. |

`#F9FAFB`, `#EEF1F3` and `#9FA9B1` exist only as stops inside those gradients. They are not palette tokens: never use them as flat fills, text or UI colours.

## Files and where to import them

| File | What it is | Import into |
|---|---|---|
| `MVtech_Color_Swatches.png` / `.pdf` | Swatch sheet (1920 × 1080 PNG; A4 landscape vector PDF): every token with hex/RGB/CMYK/role, the four gradients and the text-contrast matrix. | Share with printers, agencies, new hires. |
| `mvtech-palette.json` | Master data: name, hex, rgb, hsl, cmyk_approx, role, usage and WCAG contrast (ratio + AA/AAA class) against white and Ink, plus gradients. | Any script or build step. |
| `tokens.w3c.json` | W3C Design Tokens Community Group format (`$type` / `$value`), groups `color`, `gradient`, `semantic`. | **Figma**: Tokens Studio plugin → *Import → JSON file* (or point it at this file in a Git repo), then *Create styles / variables*. **Style Dictionary** v4+: use as a source file. Also readable by Penpot and Supernova. |
| `mvtech-colors.css` | CSS custom properties on `:root` (`--mv-*` tokens, `--mv-*-rgb` triplets for alpha, `--gradient-*`) with semantic aliases `--color-bg / -surface / -text / -text-muted / -link / -accent / -accent-soft`, a `[data-theme="dark"]` block and a `prefers-color-scheme` fallback. | Web: `<link rel="stylesheet" href="mvtech-colors.css">`, then `color: var(--color-text)`. |
| `mvtech-colors.scss` | `$mv-*` variables, `$mvtech-colors` and `$mvtech-gradients` maps, semantic aliases. | Sass projects: `@use "mvtech-colors" as mv;`. |
| `tailwind.colors.cjs` | Node module exporting `colors`, `backgroundImage` and `semantic`. | **Tailwind CSS** — in `tailwind.config.js`: `const mvtech = require('./tailwind.colors.cjs'); … theme.extend.colors.mvtech = mvtech.colors; theme.extend.backgroundImage = mvtech.backgroundImage;` → classes `bg-mvtech-ink`, `text-mvtech-teal-ink`, `bg-mvtech-teal-ramp`. |
| `mvtech.ase` | Adobe Swatch Exchange (ASEF 1.0, one "MV.tech" group, 11 global RGB swatches). | **Illustrator / InDesign**: Swatches panel menu → *Open Swatch Library → Other Library…*. **Photoshop**: Swatches panel menu → *Import Swatches…*. **Affinity Designer / Photo / Publisher**: Swatches panel menu → *Import Palette → As Application (or Document) Palette*. Also opens in Sketch and Procreate. |
| `mvtech.gpl` | GIMP palette (also Inkscape, Krita, MyPaint, Aseprite). | **GIMP**: *Windows → Dockable Dialogs → Palettes* → right-click → *Import Palette → Palette file*; or copy to `~/.config/GIMP/2.10/palettes/`. **Inkscape**: copy into the `palettes/` folder of your Inkscape user profile (*Edit → Preferences → System → User palettes* shows the path), restart, then pick "MV.tech" from the palette-bar menu. **Krita**: Palette docker → *Import*. |
| `mvtech-office-theme-colors.xml` | DrawingML `<a:clrScheme name="MV.tech">` with the 12 Office theme slots. | **PowerPoint / Word**: see `PowerPoint_Theme_Colors_How_To.md` — enter the values via *Design → Colors → Customize Colors*, or drop the file into your Office *Theme Colors* folder. |
| `PowerPoint_Theme_Colors_How_To.md` | Step-by-step guide for applying the Office colour scheme (Windows, macOS, Google Slides). | — |

## Semantic roles

| Alias | Light UI | Dark UI |
|---|---|---|
| `--color-bg` | White | Ink |
| `--color-surface` | Silver | Navy |
| `--color-text` | Navy | White |
| `--color-text-muted` | Graphite | Slate |
| `--color-link` | Teal Ink | Signal Teal |
| `--color-accent` | System Cyan (decorative) | Signal Teal |
| `--color-accent-soft` | Cyan 12 % | Teal 14 % |

## Regenerating

The generator ships with the kit, at `_source/build_tokens.py`. It holds the one source table — the eleven colours and the four gradients — and writes every machine-readable export in this folder from it. Do not hand-edit the exports; change the table and re-run:

```
cd 10_Color_and_Design_Tokens/_source
python3 build_tokens.py
```

Python 3.8+ with no third-party packages. It rewrites eight files in the folder above it — `mvtech-palette.json`, `tokens.w3c.json`, `mvtech-colors.css`, `mvtech-colors.scss`, `tailwind.colors.cjs`, `mvtech-office-theme-colors.xml`, `mvtech.gpl` and `mvtech.ase` (which it verifies by parsing back) — and writes the swatch-sheet layout to `_source/MVtech_Color_Swatches.html`, loading Inter from `09_Fonts/Inter_Desktop_TTF/`.

The two swatch-sheet exports are then rendered from that one HTML with headless Chrome, and the script prints the exact Playwright/Puppeteer calls when it finishes: a 1920 × 1080 screenshot for `MVtech_Color_Swatches.png`, and `page.pdf({ printBackground: true, preferCSSPageSize: true })` for `MVtech_Color_Swatches.pdf` (the `@page` rule in the HTML asks for 297 × 210 mm and a print media query re-lays the sheet for that page). By hand: open the HTML in Chrome and use *Print → Save as PDF* with background graphics on. Check the PNG comes out exactly 1920 × 1080 and the PDF is a single A4-landscape page.

Two files here are written by hand and are **not** generated: this `README.md` and `PowerPoint_Theme_Colors_How_To.md`. Update them yourself when a value, a file or a count changes.

If a gradient changes, it must change in the monogram master (`02_Logos/00_Master_Vector/mvtech-monogram-*.svg`) and in the `GRADIENTS` table of `build_tokens.py` together. The script enforces that: on every run it re-reads `mvtech-monogram-dark.svg` and checks each gradient's stop colours, stop positions and gradient vector against the mark, and fails loudly if the mark carries a gradient the table does not. Read the `CHECK` lines it prints — they should end with `GRADIENTS MATCH THE MONOGRAM MASTER`.
