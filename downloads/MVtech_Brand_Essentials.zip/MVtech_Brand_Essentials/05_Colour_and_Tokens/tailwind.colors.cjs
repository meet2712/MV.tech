// MV.tech colour tokens v2 for Tailwind CSS - generated 2026-09-11 by _source/build_tokens.py
// tailwind.config.js:
//   const mvtech = require('./tailwind.colors.cjs');
//   module.exports = { theme: { extend: { colors: { mvtech: mvtech.colors }, backgroundImage: mvtech.backgroundImage } } };
// Classes: bg-mvtech-ink  text-mvtech-navy  text-mvtech-teal-ink  border-mvtech-slate/30  bg-mvtech-teal-ramp
'use strict';

const colors = {
  'ink': '#05060B', // Ink - Primary dark background
  'navy': '#071118', // Navy - Text; the mark on light backgrounds
  'teal': '#10F5D0', // Signal Teal - Primary accent, dot, highlights on dark
  'cyan': '#00BFCB', // System Cyan - Gradient support; accent separators on light
  'deep-teal': '#087D9B', // Deep Teal - Gradient start (dark end of teal ramp)
  'teal-ink': '#007E7B', // Teal Ink - ONLY teal allowed for text/links on white (4.9:1 AA)
  'silver': '#F4F6F8', // Silver - Light mark, light surfaces
  'slate': '#8DA0B5', // Slate - Secondary text on dark (7.6:1) - NOT for text on white (2.7:1)
  'graphite': '#405466', // Graphite - Secondary text on light (7.8:1)
  'mist': '#718394', // Mist - Tertiary/caption text on light (3.9:1, large only)
  'white': '#FFFFFF', // White - Paper
};

// The four fills of the monogram master, at the angle to use in UI work. Inside the mark
// the same stops run at 29deg / 120deg / 225deg / 199deg - see mvtech-palette.json.
const backgroundImage = {
  'mvtech-teal-ramp': 'linear-gradient(45deg, #087D9B 0%, #00C9C8 55%, #18F2CF 100%)',
  'mvtech-silver-ramp': 'linear-gradient(180deg, #FFFFFF 0%, #F9FAFB 35%, #F5F7F8 60%, #AAB4BC 100%)',
  'mvtech-facet': 'linear-gradient(225deg, #1D252A 0%, #3E464B 12.5%, #82898E 37.5%, #C3C7CA 62.4%, #D9DBDD 72.4%, #F0F1F2 87.3%, #FAFAFB 100%)',
  'mvtech-fold': 'linear-gradient(199deg, #0A1015 0%, #384044 100%)',
};

// Semantic tokens you may map onto your own theme keys
const semantic = {
  light: { bg: colors.white, surface: colors.silver, text: colors.navy, textMuted: colors.graphite, link: colors['teal-ink'], accent: colors.cyan },
  dark:  { bg: colors.ink, surface: colors.navy, text: colors.white, textMuted: colors.slate, link: colors.teal, accent: colors.teal },
};

module.exports = { colors, backgroundImage, semantic };
