# 11_Icons — MV.tech brand icon set (v2)

20 line icons in three brand colourways plus a 512 px "tile" version of each. The glyphs are from the open-source **Lucide** icon library (v0.468.0, ISC licence — see the bottom of this file); MV.tech adds the colour system, export sizes and the tile treatment. Open `mvtech-icon-sheet.png` to see everything at once.

## What is in the folder

```
11_Icons/
  svg/teal/        mvtech-icon-<name>-teal.svg       Signal Teal #10F5D0 — for Ink / Navy / dark surfaces
  svg/teal-ink/    mvtech-icon-<name>-teal-ink.svg   Teal Ink   #007E7B — accent icons on white (the only teal that passes AA on white)
  svg/navy/        mvtech-icon-<name>-navy.svg       Navy       #071118 — neutral icons on white, matches body text
  png/<colourway>/64|128|256/                        transparent PNG exports of the SVGs above, e.g. png/teal/128/mvtech-icon-mail-teal-128.png
  tiles/           mvtech-icon-tile-<name>.svg + mvtech-icon-tile-<name>-512.png
                   icon centred on a 512 px Ink (#05060B) rounded square, corner radius 96, Signal Teal stroke 1.75 — corners are transparent in the PNG
  icons.json       machine-readable manifest: name -> Lucide source -> every file path, colour values, geometry
  mvtech-icon-sheet.png   contact sheet of all icons, all colourways, on their correct backgrounds
```

## The icons

| MV.tech name | Use | Lucide source |
|---|---|---|
| **Services** | | |
| `data-engineering` | Data engineering consulting | `database` |
| `custom-software` | Custom software development | `code` |
| `ai-automation` | AI automation, RAG & MCP | `brain-circuit` |
| `workflow-automation` | Workflow automation | `workflow` |
| `staff-augmentation` | IT staff augmentation | `users` |
| `tech-recruitment` | Technology recruitment | `user-search` |
| **Utility** | | |
| `mail` | Email | `mail` |
| `calendar` | Calendar / book a call | `calendar` |
| `globe` | Website / remote-first | `globe` |
| `map-pin` | Location | `map-pin` |
| `phone` | Phone | `phone` |
| `linkedin` | LinkedIn | `linkedin` |
| `github` | GitHub | `github` |
| `check-circle` | Done / included | `circle-check` (Lucide renamed `check-circle` → `circle-check`; MV.tech keeps the familiar name) |
| `arrow-right` | Next / CTA arrow | `arrow-right` |
| `clock` | Time / any timezone | `clock` |
| `shield-check` | Security / trust | `shield-check` |
| `layers` | Stack / architecture | `layers` |
| `server` | Infrastructure | `server` |
| `sparkles` | AI / new | `sparkles` |

## Geometry and how to use them

- Every icon is drawn on a **24 × 24 grid**, `fill="none"`, **stroke-width 2**, round caps and round joins (Lucide's default). Scale the SVG to any size; the stroke scales with it.
- **Sizes.** Use the SVGs wherever possible (web, Figma, Office 365, Keynote). The PNGs are for tools that cannot take SVG: 64 px for UI/email, 128 px for slides, 256 px for print previews and social. Do not enlarge a PNG — pick the next size up or use the SVG. Icons should not be displayed below 16 px.
- **Colour.** The colour is baked into each file as `stroke="#…"`, so nothing needs styling. To recolour an SVG for another brand token, change only the `stroke` attribute on the root `<svg>`; never fill the shapes. Rules from the brand guidelines still apply: Signal Teal (`teal`) is for dark backgrounds only; on white use `teal-ink` or `navy`.
- **Optical size.** All icons share the same grid, so they align in rows and lists; keep at least the icon's own width of space between neighbouring icons.
- **Tiles** (`tiles/`) are the app-icon style treatment for service cards, social posts, slide bullets and feature grids: Ink rounded square, radius 96 (18.75 % of the side), glyph box 288 px (icon padding 112 px), Signal Teal stroke 1.75 for a lighter line at large sizes. Use them on white, Silver or photo backgrounds; on Ink they disappear — use the plain `teal` icon instead. Do not change the corner radius or the tile colour.
- **Web.** Inline the SVG or use it as an `<img>`; set `width`/`height` and add `aria-hidden="true"` if a text label sits next to it (the files carry `role="img"` and an `aria-label` for standalone use).
- **Do not** add fills, drop shadows, gradients or outlines, mix icons from other libraries in the same layout, or rotate/flip icons (except `arrow-right`, which may be mirrored for "back").

## Adding an icon

Pick a Lucide glyph (https://lucide.dev — the local copy is `node_modules/lucide/dist/esm/icons/<name>.js`), keep the 24 px grid and stroke 2, wrap it with the same root attributes as the existing SVGs and export the three colourways, three PNG sizes and the tile. Add it to `icons.json` and to this table so the source stays traceable.

## Licence and attribution

The icon glyphs are from **Lucide** (https://lucide.dev), version 0.468.0, used under the ISC licence. The MV.tech colour, tile and export system around them is part of the MV.tech brand kit. When redistributing the icon files (for example in a website theme or a design system), keep the notice below with them.

```
ISC License

Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
```

Colour values come from `10_Color_and_Design_Tokens/`. The logo in the icon sheet header is `02_Logos/00_Master_Vector/mvtech-lockup-horizontal-dark.svg`.
